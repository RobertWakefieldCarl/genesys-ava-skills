# ava-compliance-checker

Maps **AVA `scorecard.json`** results to themes from **one** bundled document — *AI and Virtual Agent Laws, Court Cases and Compliance Standards* — and writes **compliance-report.html** (+ **.pdf** with Puppeteer).

**Install:** extract the release zip and run `install.ps1` (Windows) or `install.sh` (macOS/Linux) from the extracted `ava-compliance-checker` folder — default target `~/.cursor/skills/ava-compliance-checker/`. Use `-All` / `--all` to copy into every detected IDE base under your profile.

**Package (maintainers):** from the skill folder run `pwsh ./scripts/package.ps1` — produces **`dist/ava-compliance-checker-<version>.zip`** with a printed SHA256 (see `MANIFEST.json` for file list).

## Quick command

```bash
node scripts/generate-compliance-report.js --scorecard "path/to/scorecard.json" --out-dir "path/to/out"
```

The HTML report includes an **executive summary**, **collapsible** scenario sections, and a **mitigation catalog** at the end. Puppeteer PDF export opens every section so the PDF is fully readable.

**Verification (after fixes + retest):** pass **`--baseline-scorecard`** (pre-fix) and optionally **`--mitigations`** (JSON describing what changed). Default output: **`compliance-verification-report.html`**. See **`examples/mitigations.example.json`**.

See **SKILL.md** for the full agent workflow and disclaimer.
