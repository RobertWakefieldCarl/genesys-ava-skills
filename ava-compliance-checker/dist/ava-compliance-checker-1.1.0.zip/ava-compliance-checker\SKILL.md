---
name: ava-compliance-checker
description: >-
  Assess a published Genesys Cloud AVA against a bundled laws-and-compliance compendium, map
  ava-evaluate scorecard results to regulatory themes and remediation, and produce HTML and PDF
  reports. Use after evaluation runs or when preparing compliance readouts for counsel or risk teams.
  Does not replace ava-corner-cases: this skill consumes scorecards and the sole source document only.
disable-model-invocation: true
metadata:
  version: 1.1.0
  reference_document: assets/AI_and_Virtual_Agent_Laws_Cases_and_Compliance_Standards.md
---

# AVA compliance checker

Turn **AVA evaluation output** (`scorecard.json` from **[ava-evaluate](../ava-evaluate/SKILL.md)**) into a **structured compliance report** (HTML + PDF) grounded **only** in the bundled research file:

`<SkillDir>/assets/AI_and_Virtual_Agent_Laws_Cases_and_Compliance_Standards.md`

(*AI and Virtual Agent Laws, Court Cases and Compliance Standards*, v1.0 November 2026.)

Mapping from scenarios to legal/regulatory themes uses **`<SkillDir>/data/evidence-map.json`**, whose content is **derived from that single Markdown file** (Parts 1–3: laws, cases, PCI/HIPAA/financial/security/accessibility standards). Expand `evidence-map.json` if your test vocabulary uses different terms; do not import external compliance corpora unless the user replaces the bundled MD.

**This is not legal advice.** The bundled document states it is not legal advice; reports must repeat that counsel should confirm applicability.

## Relationship to ava-corner-cases

- **ava-corner-cases** — authors `corner-*` scenarios from security guidelines and runs evaluation.
- **ava-compliance-checker** — **does not** author tests; it **ingests any** `scorecard.json` (functional, corner, empathy, mixed) and **maps results** to the laws/cases/standards compendium.

## Prerequisites

- A **`scorecard.json`** from a completed eval run (see `.ava-lifecycle/<slug>/eval-runs/<run-id>/scorecard.json`).
- **Node.js** on the path.
- **PDF:** optional **`puppeteer`** (`npm install` in `<SkillDir>` or print the HTML from a browser). Without Puppeteer, the script still writes `compliance-report.html` and explains how to print to PDF.

## Workflow (agent)

### Phase 1 — Assess and report

1. **Resolve** `<SkillDir>` as the directory containing this `SKILL.md`.
2. **Copy** the bundled source into the lifecycle folder for audit if the user wants a frozen copy, e.g.  
   `.ava-lifecycle/<slug>/compliance/AI_and_Virtual_Agent_Laws_Cases_and_Compliance_Standards.md` (same bytes as `<SkillDir>/assets/...`).
3. **Locate** the latest or user-specified `scorecard.json` under `.ava-lifecycle/<slug>/eval-runs/`.
4. **Run** the generator from the target output directory (project root or lifecycle subfolder):

   ```bash
   node "<SkillDir>/scripts/generate-compliance-report.js" ^
     --scorecard "C:\path\to\eval-runs\eval-run-...\scorecard.json" ^
     --out-dir "C:\path\to\output-dir"
   ```

   Outputs:

   - `compliance-report.html` — **Executive summary** at the top; **report metadata** in a collapsible block; **test-by-test** blocks (`<details>`) you can expand — failing scenarios start **open**; law/regulation/case themes per test; **Mitigation catalog** at the end (deduplicated steps by theme). PDF generation expands all sections first so the file reads in full.
   - `compliance-report.pdf` — when Puppeteer is available.

5. **Present** the report summary to the user: counts of pass/fail, top recurring themes, and gaps where **no keyword matched** (manual review against the bundled MD).

### Phase 2 — Offer remediation (no silent edits)

6. **Do not** change `sage-agent.json`, design artifacts, or live AVA configuration **unless** the user explicitly asks to apply fixes.
7. When the user agrees, use normal **ava-design** / **ava-build** flows to: update **instructions, guardrails, tools, disclosures, hand-offs**, and **test cases** in line with the remediation column and the cited sections of the bundled document.

### Phase 3 — Verification report after mitigations (final HTML)

After fixes are deployed and **ava-evaluate** has been re-run, generate a **verification** report that ties **what you changed** to **retest results** and (optionally) a **baseline vs retest** comparison.

8. **Collect**
   - **Retest scorecard** — path to the new `scorecard.json` (the `--scorecard` argument always means *current / retest* run).
   - **Baseline scorecard** (recommended) — path to the **pre-fix** `scorecard.json` for the same suite.
   - **Mitigations JSON** (optional but recommended) — short record of edits, e.g. `.ava-lifecycle/<slug>/compliance/mitigations-applied.json`. Schema: array of items or `{ "items": [...], "global_notes": [...] }` per item: `test_case_id`, `title`, `description`, optional `areas`. See **`examples/mitigations.example.json`**.

9. **Run**

   ```bash
   node "<SkillDir>/scripts/generate-compliance-report.js" ^
     --scorecard "C:\path\to\eval-runs\eval-run-...-retest\scorecard.json" ^
     --baseline-scorecard "C:\path\to\eval-runs\eval-run-...-baseline\scorecard.json" ^
     --mitigations "C:\path\to\mitigations-applied.json" ^
     --out-dir "C:\path\to\output-dir"
   ```

   Default output file name when either `--baseline-scorecard` or `--mitigations` is present: **`compliance-verification-report.html`** (and matching **`.pdf`**). Override with `--output-html my-report.html`. Single-run assessments (no baseline, no mitigations file) still default to **`compliance-report.html`**.

10. **Deliver** the verification HTML/PDF: executive summary reflects the **retest**; sections include **Mitigations applied**, **Before / after** (baseline → retest per `testCaseId`), **Retest — test-by-test results**, then the **Mitigation catalog** (reference compendium themes).

## What the report contains

| Section | Content |
|--------|---------|
| Executive summary | Pass/fail/review counts, harness summary line, list of failing scenarios, most common matched themes, unmapped count. |
| Mitigations applied *(verification)* | Human-written fixes from `--mitigations` JSON. |
| Before / after *(verification)* | Per-scenario baseline vs retest outcome when `--baseline-scorecard` is set. |
| Report metadata | Run id, agent version, paths — collapsible. |
| Test-by-test results | Collapsible per scenario: harness failures + law/case/regulatory themes (mitigation steps only in the catalog at the end). |
| Mitigation catalog | End of document: deduplicated remediation bullets grouped by compliance theme from `evidence-map.json`. |
| Result | Pass / fail / review derived from scenario verdict and layer2 dimension failures. |
| Law / case / standards | Short bullets pointing to **Part 1–3** themes in the bundled MD; optional case-law lines where the map lists them. |

## Customizing the map

Edit **`data/evidence-map.json`**:

- Add **keywords** that appear in your scenario titles, assertions, or failure reasons.
- Add **regulatory_refs**, **case_law_refs**, and **document_sections** using **only** information present in the bundled MD.

## Files

| Path | Role |
|------|------|
| `assets/AI_and_Virtual_Agent_Laws_Cases_and_Compliance_Standards.md` | Sole legal/compliance source (v1.0). |
| `data/evidence-map.json` | Keyword → control → remediation + citations from that MD. |
| `examples/mitigations.example.json` | Sample `--mitigations` file for verification reports. |
| `scripts/generate-compliance-report.js` | Builds HTML/PDF. |
