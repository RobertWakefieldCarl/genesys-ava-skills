# AI and Virtual Agent Laws, Court Cases and Compliance Standards

**Version:** 1.0 (November 6, 2026)
**Scope:** Laws and regulations (US local, state and federal; EU and EU member states; UK) that govern the use of AI or virtual agents; US and international court cases and enforcement decisions in which AI was part of the case; and PCI, HIPAA and other organizational compliance standards that address AI and virtual agents.
**Companion file:** *Virtual Agent Corner-Case Test Catalog* turns many of these requirements into test cases (category M and others).

> **Not legal advice.** This is a research compendium built from law-firm, regulator, court and news sources as of early November 2026. It is comprehensive for the topics a customer-facing virtual agent is likely to touch, but no list of AI law can be complete: US states alone introduced more than 1,500 AI bills in 2026. Status labels and dates change quickly, and several sources conflicted. Items marked **(verify)** rest on a single secondary source or on background knowledge; Part 4 lists the open items. Have counsel confirm applicability before relying on any entry.

**Status labels used throughout**

| Label | Meaning |
|---|---|
| **In force** | Currently applies |
| **Enacted, not yet effective** | Signed or adopted, with a future effective or application date |
| **Pending** | Bill or proposal moving through a legislature, or a proposed rule |
| **Guidance** | Regulator guidance, policy statement or voluntary code; not binding law but used in enforcement |
| **Stayed / contested** | Enforcement paused or under legal challenge |

---

## Contents

- [Part 1. Laws and regulations](#part-1-laws-and-regulations)
  - [1.1 US local laws](#11-us-local-laws)
  - [1.2 US state laws](#12-us-state-laws)
  - [1.3 US laws that cut across many states](#13-us-laws-that-cut-across-many-states)
  - [1.4 US federal laws, regulations and executive actions](#14-us-federal-laws-regulations-and-executive-actions)
  - [1.5 European Union](#15-european-union)
  - [1.6 EU member-state laws](#16-eu-member-state-laws)
  - [1.7 United Kingdom](#17-united-kingdom)
  - [1.8 International treaty](#18-international-treaty)
- [Part 2. Court cases and enforcement decisions involving AI](#part-2-court-cases-and-enforcement-decisions-involving-ai)
- [Part 3. Compliance standards for AI and virtual agents](#part-3-compliance-standards-for-ai-and-virtual-agents)
- [Part 4. Open items to verify](#part-4-open-items-to-verify)
- [Part 5. Sources](#part-5-sources)

---

# Part 1. Laws and regulations

## 1.1 US local laws

City and county rules are few but can carry their own enforcement. Most local AI activity is internal government policy (procurement rules, AI registers) rather than law that binds private virtual agents.

| Jurisdiction and law | Status | What it requires | Relevance to virtual agents |
|---|---|---|---|
| **New York City Local Law 144 (automated employment decision tools)** | In force since July 5, 2023 | Employers and agencies using automated tools to screen candidates or employees for NYC jobs must obtain an annual independent bias audit, publish a summary and give notice to candidates; enforcement by the city's consumer protection department (DCWP); no private right of action. A December 2025 New York State Comptroller audit found enforcement ineffective (for example, most related 311 calls were misrouted and the Comptroller found 17 potential violations where DCWP found one); DCWP committed to more proactive enforcement | Recruiting and HR virtual agents that screen, rank or schedule candidates |
| **New York City biometric identifier law (NYC Admin. Code 22-1201 and following)** | In force since 2021 (verify) | Commercial establishments that collect biometric identifiers must post notice and may not sell them; private right of action | Voice or face identification used at physical locations, kiosks or drive-throughs |
| **Portland, Oregon ban on private-entity facial recognition in places of public accommodation** | In force since 2021 (verify) | Prohibits private businesses from using face recognition in places open to the public | Kiosk, retail and drive-through agents with cameras |
| **City and county bans on government facial recognition (for example San Francisco, Boston, King County)** | In force (verify each) | Restrict government use; do not bind private businesses | Government virtual agents and public-sector deployments |
| **Municipal AI policies (for example Seattle, San Jose, Boston, New York City)** | Guidance | Procurement, transparency and AI-register requirements for city use | Vendors selling virtual agents to cities must meet them by contract |

## 1.2 US state laws

The table lists enacted laws and significant pending bills that bear directly on AI or virtual agents. Section 1.3 lists categories that exist in many states (privacy, recording, biometrics, insurance, deepfakes).

| State | Law | Status | What it requires |
|---|---|---|---|
| **California** | BOT Act (SB 1001, Bus. & Prof. Code 17940 and following) | In force since 2019 | Disclose a bot used to incentivize a sale or influence a vote, where a person could be misled |
| California | SB 243 (companion chatbots) | In force January 1, 2026 | Disclosure that a companion chatbot is AI; self-harm and suicide protocols; protections for minors |
| California | **AB 1609, Right to Human Customer Service Act** | Enacted (signed September 28, 2026), effective January 1, 2027 | For businesses with more than USD 500 million in annual revenue: may not present a customer-service chatbot as a person; disclose it is artificial in the same medium; offer a simple way to reach a human on every customer-service platform during business hours; connect within 15 minutes or schedule a callback within one business day; limit phone holds after reaching an agent to 15 minutes each and one hour cumulatively; public-prosecutor enforcement, USD 5,000 first violation and USD 10,000 per later violation (secondary sources; verify text) |
| California | AI Transparency Act (SB 942 as amended by AB 853) | In force August 2, 2026; added duties for large platforms January 1, 2027 | Covered generative-AI providers must offer detection tools and provenance disclosures |
| California | CCPA regulations on automated decision-making, risk assessments and cybersecurity audits | In force January 1, 2026; ADMT compliance from January 1, 2027 | Pre-use notice, opt-out and access rights for significant automated decisions; risk assessments (existing activities by December 31, 2027); audits phased by revenue |
| California | SB 53 (Transparency in Frontier AI Act); AB 2013 (training-data transparency) | In force January 1, 2026 | Frontier developers publish safety frameworks and report incidents; generative-AI developers document training data |
| California | 2026 session: SB 947 (automated decision systems in employment, reported to bar AI-only firing decisions) and other bills on companion and customer-service chatbots, health-care AI (AB 1979, SB 503) and digital replicas; vetoes reported for AB 2575 and SB 903 | Enacted (effective dates verify; sources conflict) | Workplace, health-care and customer-service obligations |
| California | Invasion of Privacy Act (CIPA), Penal Code 631 and 632 | In force | All-party consent to record or eavesdrop; USD 5,000 statutory damages per violation; used against AI chat and call-analytics vendors (Part 2.3) |
| California | SB 1120 (physicians make medical-necessity decisions in utilization review) | In force January 1, 2025 | AI may support but not replace clinician review of coverage denials |
| **Colorado** | Colorado AI Act (SB 24-205) | Stayed / contested: enforcement stayed by a federal court on April 27, 2026 in litigation brought by xAI, with DOJ intervening; repeal-and-replace also reported | Original high-risk AI duties (developer and deployer care, impact assessments) |
| Colorado | SB 26-189 (automated decision-making transparency) | Enacted, effective January 1, 2027 (verify) | Transparency for consequential automated decisions |
| Colorado | Chatbot Safety Act (HB 26-1263) | Enacted (signed May 29, 2026), effective January 1, 2027 | Clear disclosure that a user is interacting with AI |
| **Connecticut** | 2026 chatbot-safety law (verify bill number); broader ADMT bill (SB 2) did not pass | Enacted (verify) | Chatbot safety and disclosure |
| **Florida** | Telephone Solicitation Act (FTSA) and Security of Communications Act | In force | Mini-TCPA rules for automated calls and texts; all-party consent to record |
| **Georgia** | SB 540 (2026 chatbot law) | Enacted (verify) | Chatbot safety provisions |
| **Idaho** | S 1297 (2026 chatbot law) | Enacted (verify) | Chatbot safety provisions |
| **Illinois** | Biometric Information Privacy Act (BIPA) | In force | Written notice and consent before collecting voiceprints or face geometry; retention schedule; private right of action (2024 amendment limits damages to one recovery per person, verify) |
| Illinois | HB 3773 (Human Rights Act amendment on AI in employment) | In force January 1, 2026 | No discriminatory AI use in employment decisions; notice when AI is used |
| Illinois | Artificial Intelligence Video Interview Act | In force since 2020 | Notice, explanation and consent before AI analysis of video interviews; deletion on request |
| Illinois | Wellness and Oversight for Psychological Resources Act (AI therapy limits) | In force 2025 (verify) | Restricts AI from providing therapy or presenting as a licensed therapist |
| Illinois | Frontier AI safety law (third state after California and New York) | Enacted (effective date verify) | Frontier developer duties |
| Illinois | HB 2435 (bot disclosure) | Pending (passed House April 2025) | Bot disclosure |
| **Iowa** | SF 2417 (2026 chatbot law) | Enacted (verify) | Chatbot safety provisions |
| **Louisiana** | HB 686 (disclosure at the start of AI-made calls); HB 639 (AI in political calls) | Pending (status unclear) | AI-voice call disclosure |
| **Maine** | LD 1727 (AI chatbots in trade) | In force 2025 (verify) | Unfair trade practice to use an AI chatbot that could mislead a consumer into thinking they are dealing with a human, unless disclosed |
| **Maryland** | Mini-TCPA amendments (2024); facial-recognition-in-interviews law (2020); Wiretap Act | In force | Automated-call rules; consent before facial recognition in job interviews; all-party consent to record |
| **Michigan** | SB 760 (chatbot safety) | Pending (passed Senate May 2026) | Chatbot safety |
| **Nebraska** | LB 525 (2026 chatbot law) | Enacted (verify) | Chatbot safety provisions |
| **Nevada** | Limits on AI in mental-health care (2025) | In force (verify) | Restricts AI representing itself as a mental-health provider |
| **New Jersey** | Mini-TCPA law (2024) | In force | Automated-call and text rules |
| **New York** | S9051-B / A10379-C (unsafe companion features for minors), General Business Law Article 48 | Enacted (signed October 28, 2026), reported effective January 1, 2027 (verify) | Bars 12 categories of unsafe companion features for minors, including pretending to be human, encouraging self-harm and sexual content; age assurance required before such features stay on; up to USD 25,000 per violation; attorney general may add features |
| New York | AI companion safeguards law (2025) | In force (verify date) | Crisis-detection protocols and periodic disclosure for AI companions |
| New York | RAISE Act (frontier models) | Enacted, effective January 1, 2027 (verify) | Frontier developer safety frameworks and incident reporting; DFS oversight |
| New York | Algorithmic pricing disclosure; synthetic performer disclosure in advertising | In force (verify dates) | Disclose personalized algorithmic pricing; disclose synthetic performers in ads |
| New York | AB 2593 (consent for artificial or prerecorded voice robocalls) | Pending (introduced 2025) | AI-voice call consent |
| **Oklahoma** | Telephone Solicitation Act | In force | Mini-TCPA rules |
| **Oregon** | HB 3865 (telephone solicitation) | In force January 1, 2026 | Covers texts; opt-out mechanisms and disclosures for automatic dialing and artificial-voice calls; reported limit of 3 solicitation calls per 24 hours (verify enacted text) |
| Oregon | SB 1546 (companion chatbots); HB 2748 (AI may not use nursing titles) | Enacted 2026 / in force January 1, 2026 (verify) | Companion-chatbot safety; no AI posing as a nurse |
| **Pennsylvania** | SB 1090 / HB 2006 (companion chatbots) | Pending (each passed one chamber) | Companion-chatbot safety |
| **Rhode Island** | 2026 chatbot law | Enacted (verify) | Chatbot safety provisions |
| **Tennessee** | ELVIS Act (2024); 2026 chatbot law | In force / enacted (verify) | Protects voice and likeness against unauthorized AI cloning; chatbot safety |
| **Texas** | Responsible AI Governance Act (TRAIGA, HB 149) | In force January 1, 2026 | Bans AI intended to manipulate people toward self-harm or crime, unlawful intentional discrimination and certain sexual deepfakes; disclosure for government and some health-care AI; AG-only enforcement with 60-day cure; NIST AI RMF alignment helps as a defense |
| Texas | Capture or Use of Biometric Identifier Act (CUBI) | In force | Consent before capturing biometric identifiers; AG enforcement (Part 2.3 for settlements) |
| Texas | SB 140 (telephone solicitation expansion) | In force | Broader solicitation rules and penalties, including texts |
| **Utah** | AI Policy Act as amended (SB 226, SB 332, HB 452, 2025) | In force; sunset extended to July 2027 | Disclose generative AI when a consumer clearly asks, and proactively in "high-risk" interactions (health, financial, legal advice, sensitive data); safe harbor for clear disclosure at the start and throughout; mental-health chatbot rules |
| **Virginia** | SB 796 (companion chatbots) | Pending (passed one chamber; session outcome verify); a 2025 high-risk AI bill (HB 2094) was vetoed (verify) | Companion-chatbot safety |
| **Washington** | HB 2225 (companion chatbots) | Enacted (signed March 24, 2026), effective January 1, 2027 | Clear disclosure that the bot is not human at the start of each interaction and periodically; disclosure that it is not a medical professional when medical advice is sought; may not claim to be human; self-harm safeguards; annual public reporting; stronger protections for minors; enforced under the Consumer Protection Act with a private right of action (business-operations bots reported exempt; verify scope) |
| Washington | Biometric identifiers law (RCW 19.375); My Health My Data Act | In force | Biometric notice and consent; consumer health data consent with a private right of action |

**Volume indicator:** trackers reported 1,561 AI-related bills in 45 states by March 2026 and laws passed or enacted in 30 states between January 1 and October 15, 2026, including 14 chatbot-safety laws in the first half of the year.

## 1.3 US laws that cut across many states

| Category | States (verify current list) | What it means for virtual agents |
|---|---|---|
| **Comprehensive consumer privacy laws** (opt-outs from profiling for significant decisions, sensitive-data consent, data-protection assessments) | California, Colorado, Connecticut, Delaware, Indiana, Iowa, Kentucky, Maryland, Minnesota, Montana, Nebraska, New Hampshire, New Jersey, Oregon, Rhode Island, Tennessee, Texas, Utah, Virginia | Notice, opt-out of profiling, assessments for high-risk processing, rights requests that reach transcripts and recordings |
| **All-party consent to record calls** | California, Florida, Illinois, Maryland, Massachusetts, Montana, New Hampshire, Pennsylvania, Washington, and others in some circumstances (for example Connecticut, Delaware, Nevada) | Notice and consent before recording or AI analysis; apply the stricter rule on interstate calls |
| **Biometric privacy laws** | Illinois (BIPA), Texas (CUBI), Washington; biometric provisions in several comprehensive privacy laws | Consent before voiceprints or face data; retention and deletion |
| **State "mini-TCPA" and telemarketing laws** | Florida, Oklahoma, Maryland, New Jersey, Oregon, Texas, Utah and others | Stricter calling hours, consent, frequency caps, registration and private rights of action |
| **State Do-Not-Call lists** | Many states | Scrub per state in addition to the national registry |
| **NAIC Model Bulletin on insurers' use of AI** (adopted as state bulletins) | About 24 to 25 states plus D.C. (NAIC map as of May 1, 2026) | Governance program, risk management, vendor oversight and documentation for insurer AI |
| **AI in health-insurance utilization review** | Several states (for example California SB 1120) | Licensed clinicians must make adverse medical-necessity decisions |
| **Election deepfake laws** | A majority of states | Disclosure or bans on deceptive AI election content near elections |
| **Non-consensual intimate deepfakes** | Nearly all states | Criminal and civil liability for AI sexual imagery |
| **Voice and likeness (right of publicity)** | Tennessee (ELVIS Act), California, New York and others | Consent before cloning a real person's voice or likeness |

## 1.4 US federal laws, regulations and executive actions

| Law, rule or action | Status | Relevance to virtual agents |
|---|---|---|
| **Telephone Consumer Protection Act (TCPA) and FCC Declaratory Ruling FCC 24-17 (February 2024)** | In force | AI-generated voices count as "artificial or prerecorded voice"; prior express consent for calls to wireless numbers, prior express written consent for telemarketing; 8 a.m. to 9 p.m. calling hours; Do-Not-Call; opt-out mechanism; USD 500 per violation, up to USD 1,500 if willful |
| FCC TCPA consent-revocation order (adopted September 30, 2026) | Enacted, not yet effective (effective 30 days after Federal Register publication; date not confirmed); "revoke all" deferred to January 31, 2027 | Category-specific revocation for informational calls; revoke-all for telemarketing |
| FCC one-to-one consent rule (2023) | Vacated by the Eleventh Circuit (January 2025) and later repealed | Pre-2023 written-consent standard governs |
| FCC AI-generated call NPRM (August 2024) | Pending; no adopted rule found | Would define AI-generated calls and require AI disclosure |
| STIR/SHAKEN caller-ID authentication rules | In force | Accurate, authenticated caller ID for outbound agents |
| **FTC Act Section 5** (unfair or deceptive practices) | In force | Deceptive bot claims, undisclosed AI, unsubstantiated "AI" marketing (Part 2.7) |
| FTC Government and Business Impersonation Rule | In force since April 2024; extension to individuals proposed | Bots may not impersonate governments, businesses or (if extended) individuals |
| Telemarketing Sales Rule | In force | Disclosures, misrepresentation bans, recordkeeping |
| **Children's Online Privacy Protection Act (COPPA) and amended Rule** | In force; amended Rule effective June 23, 2025, compliance by April 22, 2026; FTC policy statement of February 25, 2026 limits enforcement for data collected solely for age verification | Verifiable parental consent, retention limits and security program for child-directed agents |
| **TAKE IT DOWN Act (2025)** | In force; FTC enforcement of platform duties from May 19, 2026 | Covered platforms must remove non-consensual intimate images, including AI-generated ones, within 48 hours of a valid request; penalties reported up to USD 53,088 per violation |
| CAN-SPAM Act | In force | Commercial email sent by agents |
| **Equal Credit Opportunity Act and Regulation B; Fair Credit Reporting Act** | In force | Specific adverse-action reasons even when AI is used (CFPB Circulars 2022-03 and 2023-03; current status after the CFPB's 2025 guidance review verify) |
| Gramm-Leach-Bliley Act and FTC Safeguards Rule | In force | Security program for customer financial data |
| Fair Housing Act; Title VII; ADEA; ADA | In force | Discrimination through algorithms (Part 2.5); EEOC withdrew its AI technical assistance in January 2025 (verify), but the statutes still apply |
| **HIPAA Privacy, Security and Breach Notification Rules** | In force; Security Rule overhaul proposed January 2025, final status not confirmed | Business associate agreements, minimum necessary, safeguards, breach notice (Part 3.2) |
| **Section 1557 nondiscrimination rule, 45 CFR 92.210** | In force; compliance reported due May 1, 2025 | Reasonable efforts to identify and mitigate discrimination risk from patient-care decision-support tools |
| ONC HTI-1 rule, 45 CFR 170.315(b)(11) | In force | Certified health IT must support source attributes and risk management for evidence-based and predictive decision-support interventions |
| CMS Medicare Advantage rule (CMS-4201-F) and February 6, 2024 FAQ | In force | Algorithms may assist but coverage decisions must reflect individual circumstances; predictions alone cannot end post-acute care |
| FDA clinical decision support and general wellness guidance (January 2026) | Guidance | Which AI health functions are regulated devices |
| 42 CFR Part 2 | In force | Substance-use treatment records |
| Americans with Disabilities Act; DOJ Title II web rule | In force; Title II compliance dates extended (large public entities April 26, 2027) at WCAG 2.1 AA | Accessible chat and voice channels |
| Section 508 of the Rehabilitation Act | In force | Accessibility for federal agencies and their vendors |
| **Executive Orders 14148 and 14179 (January 2025)** and **Executive Order 14365 (December 11, 2025)** | In force | EO 14148 revoked the 2023 AI executive order (EO 14110) and EO 14179 set a new pro-innovation AI policy (verify); EO 14365 directs a DOJ AI Litigation Task Force to challenge "onerous" state AI laws and ties some BEAD funding to state AI policy (Commerce's list not published as of October 27, 2026) |
| OMB memoranda M-25-21 and M-25-22 (April 2025) | In force for federal agencies (verify) | AI use and procurement rules for agencies buying virtual agents |
| Copyright Act; Copyright Office AI reports (2025) | In force / guidance | Human authorship required (Part 2.8); training-data questions |
| **Pending federal bills** | Pending | GUARD Act (S.3062, passed Senate Judiciary 22-0 on April 30, 2026; would bar AI companions for minors and require non-human disclosure); House companion H.R.8623; FRONTIER Act (July 2026) and other preemption proposals; no preemption statute as of October 27, 2026 |

## 1.5 European Union

| Instrument | Status | Relevance to virtual agents |
|---|---|---|
| **AI Act (Regulation (EU) 2024/1689)** | In force in stages: prohibitions and AI literacy from February 2, 2025; general-purpose AI duties from August 2, 2025; **Article 50 transparency from August 2, 2026** | Tell users they are interacting with AI unless obvious; mark synthetic audio, images, video and text; label deepfakes; prohibited manipulative and exploitative practices; high-risk duties for uses such as credit, employment and essential services. Fines up to EUR 35 million or 7% of turnover for prohibited practices |
| Digital Omnibus on AI (Regulation (EU) 2026/1744) | In force July 27, 2026 | Moves stand-alone high-risk obligations (reported December 2, 2027; conflicting sources) and product-embedded high-risk to August 2, 2028; marking transition for existing systems to December 2, 2026 |
| Code of Practice on marking and labelling AI-generated content | Guidance (final June 10, 2026; voluntary) | Practical route to Article 50 compliance |
| **GDPR (Regulation (EU) 2016/679)** | In force | Lawful basis, transparency, Article 22 automated decisions, DPIAs, data-subject rights, transfers, processor contracts; CJEU case law on automated scoring and explanations (Part 2.3) |
| Digital Omnibus on data (GDPR, ePrivacy and Data Act changes), procedure 2025/0360(COD) | Pending (Council mandate October 21, 2026; Parliament vote expected 2027) | Reported 96-hour breach notification and cookie changes |
| **ePrivacy Directive (2002/58/EC)** | In force | Consent for automated marketing calls and for cookies or SDKs in chat widgets |
| **Digital Services Act** | In force | Duties for platforms that host or recommend content, including generative features |
| **Consumer law: Unfair Commercial Practices Directive, Consumer Rights Directive** | In force | Misleading bot statements, dark patterns, cancellation friction |
| Digital Fairness Act | Pending (Commission proposal expected November 2026) | Dark patterns, addictive design, exploitative personalization, minors |
| **Consumer Credit Directive (EU) 2023/2225** | Applies from November 20, 2026 (transposition was due November 20, 2025; several states late) | Right to human intervention, explanation and review when creditworthiness assessment uses automated processing |
| **Platform Work Directive (EU) 2024/2831** | Transposition due December 2, 2026 | Transparency, human oversight and data limits for algorithmic management of platform workers |
| **European Accessibility Act (Directive (EU) 2019/882)** | Applies since June 28, 2025 | Accessible customer-service channels, including chatbots |
| **Product Liability Directive (EU) 2024/2853** | Transposition due December 9, 2026 | Software and AI are products; strict liability for defects, including missing security updates |
| AI Liability Directive | Withdrawn by the Commission in 2025 (verify) | No separate AI fault-liability regime |
| **Cyber Resilience Act (Regulation (EU) 2024/2847)** | Reporting obligations from September 11, 2026; most obligations from December 11, 2027 | Report actively exploited vulnerabilities and severe incidents through ENISA's Single Reporting Platform; fines up to EUR 15 million or 2.5% |
| **NIS2 Directive** | In force; national transposition continuing | Security and incident reporting for in-scope entities and suppliers |
| **DORA (Regulation (EU) 2022/2554)** | In force since January 17, 2025 | ICT risk and third-party oversight for financial entities using AI vendors |
| Data Act | In force since September 12, 2025 | Data access and cloud-switching terms |
| Copyright in the Digital Single Market Directive, Article 4 | In force | Text-and-data-mining opt-outs relevant to training and retrieval content |
| Medical Device and In Vitro Diagnostic Regulations | In force | AI that diagnoses or treats |

## 1.6 EU member-state laws

| Member state | Law | Status | Notes |
|---|---|---|---|
| **Italy** | Law 132/2025 (national AI law) | In force October 10, 2025 | National principles alongside the AI Act; personality-rights protection for image, voice and likeness; criminal offenses for harmful deepfakes; implementing decrees due within 12 months |
| **Germany** | Barrierefreiheitsstärkungsgesetz (BFSG, accessibility); national AI Act implementation law | BFSG in force June 28, 2025; AI implementation law status verify | Accessible customer service; national AI supervisory structure; strict all-party consent for call recording under the Criminal Code |
| **Netherlands** | Draft Platform Work Act (published June 29, 2026) | Pending | Implements the Platform Work Directive |
| **Denmark** | Amendment giving people rights over their own face and voice (deepfakes) | Reported enacted (year and status verify) | Consent before AI imitation of a person |
| **Spain** | Draft AI law with labeling sanctions and the AESIA supervisor | Pending (verify) | Labeling of AI-generated content |
| **All member states** | National call-recording, telemarketing-register, employee-monitoring and works-council rules; national transposition of the CCD2, PWD, PLD and NIS2 | Varies | Check each country of operation |

## 1.7 United Kingdom

| Law or regime | Status | Relevance to virtual agents |
|---|---|---|
| **UK GDPR and Data Protection Act 2018, as amended by the Data (Use and Access) Act 2025** | Main provisions in force February 5, 2026; complaints-procedure duty from June 19, 2026 | Articles 22A to 22D on automated decisions (safeguards: information, representations, human intervention, contest); lawful basis; DPIAs; data-subject rights |
| **Privacy and Electronic Communications Regulations (PECR)**, as amended | In force; fines now up to GBP 17.5 million or 4% of turnover | Prior consent for automated marketing calls; TPS and Corporate TPS screening for live calls; caller identification; consent for cookies and SDKs (certain low-risk cookies exempt) |
| **Online Safety Act 2023** | In force in phases | Chatbots in scope where they enable user-to-user sharing, search or pornographic content (Ofcom guidance, December 2025); highly effective age assurance where required; government pledged on February 15, 2026 to bring all AI chatbots in scope (pending) |
| **Digital Markets, Competition and Consumers Act 2024** | Consumer-enforcement regime in force since April 2025 | Misleading AI statements, subscription traps and dark patterns; CMA fines reported up to 10% of global turnover (verify) |
| Consumer Rights Act 2015 | In force | Services must be provided with reasonable care; statements bind the trader |
| **Equality Act 2010** | In force | No discrimination; anticipatory duty to make reasonable adjustments (for example text alternatives to voice bots) |
| Public Sector Bodies Accessibility Regulations 2018 | In force | Accessible public-sector websites and apps (WCAG 2.2 AA under current guidance, verify) |
| **FCA rules (Consumer Duty, SM&CR, Principles)** | In force; FCA said on June 2, 2026 it will not add AI-specific rules | Good outcomes, vulnerable-customer support and access to human help for regulated firms |
| Ofcom General Conditions and persistent-misuse policy | In force | Valid caller ID; limits on silent and abandoned calls (background: about 3% abandoned calls per campaign per 24 hours, verify) |
| Sector cold-calling bans | In force (pensions, claims management; verify list) | Outbound AI calls may be prohibited for these products |
| Copyright, Designs and Patents Act 1988 | In force; government report of March 18, 2026 ruled out a broad training exception | Licences needed for training content unless an exception applies |
| NIS Regulations 2018; Cyber Security and Resilience Bill | In force / pending (introduced November 12, 2025) | Incident reporting and supplier security |
| Regulating for Growth Bill | Pending (announced May 13, 2026) | AI sandboxes; no standalone AI Act |
| AI Cyber Security Code of Practice (January 31, 2025) | Guidance | 13 principles for secure AI; basis for ETSI TS 104 223 (Part 3.4) |

## 1.8 International treaty

| Instrument | Status | Notes |
|---|---|---|
| **Council of Europe Framework Convention on Artificial Intelligence and Human Rights, Democracy and the Rule of Law** | Opened for signature September 5, 2024; signed by the EU, UK and US among others (ratification status verify) | Principles on transparency, oversight, accountability and remedies for AI systems |

---
# Part 2. Court cases and enforcement decisions involving AI

Cases are grouped by the issue AI raised. Each entry gives the forum, date, what happened, the reported outcome or status, and why it matters for a virtual agent. Allegations in pending cases are unproven. No large jury verdict awarding damages against a virtual-agent operator was found; most monetary outcomes are tribunal awards, settlements, regulator penalties and sanctions.

## 2.1 What a bot says: misstatements, liability and defamation

| Case | Forum and date | What happened | Outcome or status | Lesson for virtual agents |
|---|---|---|---|---|
| **Moffatt v. Air Canada** | British Columbia Civil Resolution Tribunal, February 2024 | Chatbot told a passenger he could claim a bereavement fare after travel, contrary to policy | Airline liable for negligent misrepresentation; the "separate legal entity" argument rejected; award of about CAD 650.88 plus interest and fees (about CAD 812 total) | The company owns what its bot says; ground answers in authoritative policy |
| **Clinic chatbot decision** | Higher Regional Court of Hamm, Germany, May 2026 (reported) | A clinic's website chatbot gave invented medical specialist titles | Companies can be liable for misleading chatbot statements; appeal to the Federal Court of Justice reportedly allowed | Professional claims need verified data and hard limits |
| **Publishers v. Google (AI Overviews)** | Munich Regional Court, Germany, May or June 2026 (dates differ) | AI summaries repeated false claims about two publishers | Google treated as author of the summaries; injunction granted | Generated statements about named businesses can be unlawful |
| **Walters v. OpenAI** | Superior Court of Gwinnett County, Georgia, May 2025 | ChatGPT produced a false summary accusing a radio host of embezzlement | Summary judgment for OpenAI (no proof of harm or fault; warnings and accuracy efforts considered) | Disclaimers and accuracy controls matter, but do not rely on them alone |
| **Wolf River Electric (LTL LED) v. Google** | Minnesota (federal, then reportedly remanded to state court January 2026) | AI Overview falsely said a solar company faced an attorney-general lawsuit; damages claimed of USD 110 to 210 million | Pending | False statements about businesses can cause measurable losses |
| **Starbuck v. Meta** | Delaware Superior Court, 2025 | AI chatbot made false statements about an activist | Settled August 2025 (terms undisclosed; Starbuck reportedly hired as an adviser) | Early settlement pressure in AI defamation |
| **Starbuck v. Google** | Delaware Superior Court, filed October 2025 | Similar allegations | Pending (motion to dismiss filed) | |
| **Chevrolet dealer and DPD incidents** | Not litigated (2023, 2024) | Bot "agreed" to a USD 1 car; delivery bot swore at a customer | No damages; reputational harm; bots withdrawn | Commitment and tone controls |

## 2.2 Safety, minors and wrongful death

| Case | Forum and date | What happened | Outcome or status | Lesson |
|---|---|---|---|---|
| **Garcia v. Character Technologies and Google** | US District Court, Middle District of Florida, filed 2024 | Mother alleged a companion chatbot contributed to her son's suicide | Court declined to dismiss on First Amendment grounds (2025); confidential settlement covering this and four related family suits (New York, Colorado, Texas), case terminated January 7, 2026 | Minors, companion personas and long emotional sessions need hard safety controls |
| **Raine v. OpenAI** and related suits | California state and federal courts, 2025 to 2026 | Families allege chatbot conversations contributed to suicides | Pending; a federal court reportedly ruled OpenAI must defend a related wrongful-death suit | Long-conversation safety degradation is a litigation risk |
| **Other Character.AI claims** | Including a separate Colorado wrongful-death case | Similar allegations | Pending (verify) | |

## 2.3 Privacy, recording, biometrics and automated decisions

| Case or decision | Forum and date | What happened | Outcome or status | Lesson |
|---|---|---|---|---|
| **Ambriz v. Google** | US District Court, Northern District of California, February 10, 2025 | Callers alleged Google's Contact Center AI listened to and analyzed customer-service calls | Motion to dismiss denied: Google's capability to use call data for its own purposes was enough to state a CIPA wiretap claim | AI call-analytics vendors can be third-party "eavesdroppers"; get consent before recording or analysis |
| **Popa v. Microsoft** | US Court of Appeals, Ninth Circuit, August 2025 | Website session-replay case | Narrowed Article III standing in privacy cases; commentators see it weakening the "capability" theory | Standing defenses are developing, but consent remains the safe design |
| **In re Otter.ai Privacy Litigation** | US District Court, Northern District of California (No. 5:25-cv-06911), consolidated 2025 | AI notetaker joined meetings and recorded participants who had not consented | Core wiretap, CIPA and Illinois biometric claims reported to survive; other claims dismissed; further rulings pending (sources conflict on timing) | Meeting and call assistants need all-party notice and consent |
| **Dialpad CIPA case** | San Francisco Superior Court | AI features in a phone platform | Dismissed: telephone-provider immunity | Provider status can matter |
| **Website chat wiretap appeal** | US Court of Appeals, Ninth Circuit (citation verify) | Chat-widget recording | No "telephone wire" connection under CIPA section 631(a) | Chat and voice are treated differently under CIPA |
| **Lisota v. Heartland Dental** | US District Court, Northern District of Illinois, January 13, 2026 | AI voice and call-analytics claims | Reported win for the vendor and deployer | Outcomes vary by statute and facts |
| **Texas v. Meta (CUBI)** | Texas state court, settled July 2024 | Facial-recognition data collected without consent | USD 1.4 billion settlement | Biometric consent failures are very expensive |
| **Texas v. Google** | Texas state court, settled May 2025 | Data collection claims including biometrics | About USD 1.4 billion settlement | Same |
| **Clearview AI BIPA class action** | US District Court, Northern District of Illinois, 2024 to 2025 | Scraped face images | Settlement giving the class a share of the company (about 23%); approval details verify | |
| **Information Commissioner v. Clearview AI** | UK Upper Tribunal, [2025] UKUT 319 (AAC), October 6, 2025 | GBP 7.5 million ICO fine for face scraping | ICO's jurisdiction upheld and case remitted; Clearview given permission to appeal to the Court of Appeal (December 19, 2025); outcome pending | Foreign AI providers can fall under UK GDPR through behavioral monitoring |
| **Dutch Data Protection Authority v. Clearview AI** | Netherlands, 2024 | Face scraping | EUR 30.5 million fine (verify) | |
| **OQ v. Land Hessen (SCHUFA), C-634/21** | Court of Justice of the EU, December 7, 2023 | Credit score used by lenders | A score that plays a decisive role in a third party's decision can itself be an automated decision under GDPR Article 22 (background; verify) | Scoring and triage by AI can trigger Article 22 duties |
| **CK v. Dun & Bradstreet Austria, C-203/22** | Court of Justice of the EU, February 27, 2025 | Phone contract refused after automated credit check | Data subjects are entitled to a clear explanation of how the decision was reached (not necessarily the full algorithm); trade secrets handled through court review | Be able to explain each automated decision in plain terms |
| **Italian Garante v. Luka Inc. (Replika)** | Italy, April 10, 2025 | Companion chatbot: lawful basis, age verification, transparency | EUR 5 million fine | Companion bots need age assurance and a lawful basis |
| **Italian Garante v. OpenAI** | Italy, 2024; Rome court, March 18, 2026 | EUR 15 million fine for ChatGPT data processing | Fine annulled on procedural (one-stop-shop) grounds; Irish DPC scrutiny continues | Annulment is not clearance |
| **Uber and Ola drivers (automated decisions)** | Amsterdam District Court and Court of Appeal, 2021 and 2023 | Drivers challenged automated deactivations | Courts ordered transparency and found some decisions solely automated (background; verify) | Automated account suspensions need human review |
| **NJCM v. Netherlands (SyRI)** | District Court of The Hague, February 2020 | Government welfare-fraud risk scoring | System struck down under the European Convention on Human Rights (background; verify) | Opaque risk scoring of individuals is high-risk |

## 2.4 Telemarketing and AI voice

| Case or action | Forum and date | What happened | Outcome or status | Lesson |
|---|---|---|---|---|
| **FCC v. Steve Kramer** | FCC forfeiture order, September 2024 | AI-cloned President Biden voice in New Hampshire primary robocalls with spoofed caller ID | USD 6 million fine (USD 1,000 per call for 3,000 calls, doubled); acquitted of state criminal charges June 2025; collection status unknown | Voice cloning plus spoofing brings regulatory penalties even without a conviction |
| **FCC v. Lingo Telecom** | FCC consent decree, August 2024 | Carrier transmitted the spoofed calls | USD 1 million settlement and STIR/SHAKEN compliance plan | Carriers and vendors share exposure |
| **TCPA class settlements (prerecorded or artificial voice)** | Various federal courts, 2026 | Calls without consent or after stop requests | Aidvantage USD 3 million; Concora Credit about USD 9.375 million (fairness hearing November 24, 2026); Gen Digital USD 9.95 million; The Money Source USD 1.5 million | AI voices are in the same legal category; per-call damages scale fast |
| **AI-voice marketing class action under the TCPA and Texas law** | Federal court (pending) | AI-voice marketing calls | Pending | State law adds exposure |

## 2.5 Employment and automated screening

| Case | Forum and date | What happened | Outcome or status | Lesson |
|---|---|---|---|---|
| **EEOC v. iTutorGroup** | US District Court, Eastern District of New York; consent decree approved September 8, 2023 | Recruiting software automatically rejected older applicants | USD 365,000 settlement; bans on requesting birth dates and age screening | First EEOC AI-hiring settlement |
| **Mobley v. Workday** | US District Court, Northern District of California (No. 3:23-cv-00770) | Applicant alleges AI screening discriminated by age, race and disability | Age claims allowed to proceed as a collective action (May 2025); notice issued with an opt-in deadline of March 7, 2026; further motions to dismiss largely denied in 2026; no merits ruling | Vendors can face direct liability as an employer's agent |
| **Harper v. Sirius XM Radio** | US District Court, Eastern District of Michigan (No. 2:25-cv-12403), filed August 4, 2025 | Alleged AI screening discriminated against Black applicants | Dismissed in 2025 (sources differ on whether by summary judgment or on the pleadings without prejudice; verify) | Plaintiffs must show the tool was used and caused harm |
| **ACLU complaint against Intuit and HireVue** | Colorado Civil Rights Division and EEOC, March 19, 2025 | Deaf, Indigenous employee alleged an AI video interview could not fairly assess her speech | Pending complaint | Speech-recognition bias is a disability and race issue |

## 2.6 Health and insurance algorithms

| Case | Forum and date | What happened | Outcome or status | Lesson |
|---|---|---|---|---|
| **Estate of Lokken v. UnitedHealth Group (nH Predict)** | US District Court, District of Minnesota | Medicare Advantage members allege an algorithm cut off post-acute care | Contract and good-faith claims proceed; other claims dismissed as preempted; broad discovery ordered (March 2026 order, verify year) | Algorithmic denials face discovery into how tools are used |
| **Kisting-Leung v. Cigna (PxDx)** | US District Court, Eastern District of California, filed July 2023 | Alleged bulk denials without individual physician review | Pending (current status verify) | Human review must be real |
| **Barrows v. Humana** | US District Court, Western District of Kentucky, filed 2023 | Similar post-acute care algorithm claims | Pending (verify) | |

## 2.7 Consumer protection and "AI washing" enforcement

| Matter | Forum and date | What happened | Outcome | Lesson |
|---|---|---|---|---|
| **FTC v. DoNotPay** | FTC final order, February 2025 | "Robot lawyer" claims not substantiated | USD 193,000 in refunds and consumer notice | Substantiate what the bot can do |
| **FTC v. Rite Aid** | FTC order, December 2023 (background; verify) | Facial recognition in stores produced false matches | Five-year ban on facial-recognition use | Biometric AI needs accuracy testing and oversight |
| **FTC v. Air AI** | FTC settlement, 2026 | Deceptive claims about AI agents and business opportunities | Ban on marketing business opportunities; monetary judgment reported at USD 18 million (verify) | AI-agent marketing claims are scrutinized |
| **FTC "active listening" orders (Cox Media Group, MindSift, 1010 Digital Works)** | FTC proposed consent orders, May 2026 | Claims about listening to conversations for ad targeting | Nearly USD 1 million; not final as of late May 2026 | Claims about AI listening must be accurate |
| **FTC v. Rytr** | FTC, 2024; walked back 2025 to 2026 | AI review-writing tool | Earlier action reversed under new leadership | Federal posture has narrowed; states remain active |
| **SEC v. Delphia and Global Predictions** | SEC settled orders, March 2024 | Investment advisers overstated AI use | USD 400,000 total penalties | "AI washing" is securities fraud |
| **SEC v. Presto Automation** | SEC, January 2025 | Drive-through ordering product described as AI-driven while relying on a third party's speech recognition | First AI-washing action against a public company (penalty reports differ; verify) | Describe AI capabilities and vendors accurately |
| **SEC AI-claim actions (August to September 2026)** | SEC | Three actions over AI claims (reported) | Verify | |
| **Texas v. Pieces Technologies** | Texas Attorney General, 2024 | Health-care generative AI accuracy claims | Settlement without money; five years of disclosure and monitoring | State attorneys general enforce AI accuracy claims |

## 2.8 Copyright, voice and likeness

| Case | Forum and date | What happened | Outcome or status | Lesson |
|---|---|---|---|---|
| **Bartz v. Anthropic** | US District Court, Northern District of California | Authors challenged use of pirated books in training | USD 1.5 billion class settlement; final approval July 20, 2026 | Provenance of training and retrieval content matters |
| **Kadrey v. Meta** | US District Court, Northern District of California, June 25, 2025 | Authors challenged training on their books | Summary judgment for Meta on fair use for those plaintiffs, expressly not a ruling that such training is lawful; interlocutory appeal certification reportedly refused (July 2026) | Fair use is fact-specific |
| **Thomson Reuters v. Ross Intelligence** | US District Court, District of Delaware (February 2025); Third Circuit (reported affirmance September 29, 2026, verify) | Legal research AI trained on Westlaw headnotes | Not fair use; headnotes copyrightable | Copying from a competitor's data to build a non-generative tool lost |
| **New York Times v. Microsoft and OpenAI (MDL 1:25-md-03143)** | US District Court, Southern District of New York | Newspapers challenge training and outputs | Summary-judgment briefing under way (autumn 2026) | Pending; outputs that reproduce content are a risk |
| **Getty Images v. Stability AI** | High Court of England and Wales, [2025] EWHC 2863 (Ch), November 4, 2025 | Image model trained on Getty content | Stability largely won: the model was not an infringing copy; Getty won narrow trademark points on watermarks | UK secondary-infringement theory failed for model weights |
| **GEMA v. OpenAI** | Munich Regional Court, November 11, 2025 (reported) | Song lyrics memorized and reproduced | Memorization and outputs found infringing; appeal reported (verify) | Regurgitation of protected text is a risk |
| **Thaler v. Perlmutter** | US Court of Appeals, D.C. Circuit, 130 F.4th 1039 (March 2025); Supreme Court cert denied March 2, 2026 | AI listed as sole author | Human authorship required for copyright | Purely AI-generated output is not copyrightable in the US |
| **Lehrman and Sage v. Lovo** | US District Court, Southern District of New York, July 10, 2025 | Voice actors' voices cloned for an AI voice product | Most federal trademark and copyright claims dismissed; New York right-of-publicity and consumer-protection claims proceed | Voice cloning needs consent; state law is the main remedy |

## 2.9 Courts and AI-generated errors (sanctions)

| Case | Forum and date | What happened | Outcome |
|---|---|---|---|
| **Mata v. Avianca** | US District Court, Southern District of New York, June 2023 | Lawyers filed ChatGPT-invented cases | USD 5,000 sanction (landmark) |
| **Oregon matter (two lawyers)** | US District Court, District of Oregon, 2026 (reported) | Three briefs with fabricated cases and quotes | About USD 110,000, the largest reported US AI sanction (verify) |
| **Sixth Circuit consolidated appeals** | US Court of Appeals, Sixth Circuit, 2026 | Fabricated citations | Sanctions reported at USD 15,000 to 30,000 (sources conflict) |
| **Lnu v. Blanche** | US Court of Appeals, Ninth Circuit, June 2026 (reported) | Unauthorized AI use in filings | USD 2,500 each and six-month suspension from the court |
| **Ayinde v. London Borough of Haringey; Al-Haroun v. Qatar National Bank** | High Court of England and Wales, [2025] EWHC 1040 (Admin) and Divisional Court [2025] EWHC 1383 (Admin), 2025 | Fictitious authorities, some from public AI tools | Wasted costs; no contempt proceedings on the facts; strong warning that lawyers must verify AI research |
| **Zhang v. Chen** | Supreme Court of British Columbia, February 20, 2024 | ChatGPT-invented cases | Lawyer ordered to bear the opposing side's extra costs; special costs refused |
| **Law Society of Ontario tribunal matter** | Ontario, 2026 (reported) | AI-fabricated citations | CAD 31,150 costs, reported as the largest in Canada |
| **Hussein v. Canada, 2025 FC 1138; Lloyd's Register Canada v. Choi, 2025 FC 1233** | Federal Court of Canada, 2025 | Fabricated citations | Personal costs against counsel; motion record removed |
| **Scale** | Global | A researcher's database counted more than 1,600 AI-hallucination cases worldwide by June 2026 | |

## 2.10 Patterns across the case law

1. **Companies are responsible for their bots' statements** (Air Canada, Hamm, Munich).
2. **Recording and analysis without consent is the most common privacy theory** against AI customer-service tools (Ambriz, Otter.ai), with damages per violation.
3. **Biometric consent failures produce the largest settlements** (Texas v. Meta and Google, Clearview).
4. **Automated decisions must be explainable and reviewable by a person** (Dun & Bradstreet, SCHUFA, CMS guidance in the health cases).
5. **Vendors are not shielded** (Workday as agent, Google as possible eavesdropper, Lingo Telecom).
6. **Marketing claims about AI are enforced** by the FTC, SEC and state attorneys general.
7. **Harm to minors and vulnerable users drives the highest-severity litigation** (Character.AI, OpenAI suits).
8. **Fabricated content is sanctionable** wherever AI output is used in formal proceedings.

---
# Part 3. Compliance standards for AI and virtual agents

Standards and frameworks are not laws, but contracts, auditors, card brands, regulators and insurers rely on them. This part covers what each says about AI and virtual agents and what an organization must show.

## 3.1 Payment Card Industry (PCI)

| Standard or document | Status | What it says about AI and virtual agents |
|---|---|---|
| **PCI DSS v4.0.1** | Current (published June 2024; future-dated v4.0 requirements mandatory since March 31, 2025) | Technology-neutral: any chatbot, voice agent, model, transcript store, log pipeline or analytics tool that stores, processes or transmits cardholder data, or can affect the cardholder data environment, is in scope |
| **Integrating Artificial Intelligence in PCI Assessments Guidelines** (v1.0) | Published March 2025 | Assessors may use AI only to support, not replace, human assessors; governs AI use in the assessment process itself |
| **AI Principles: Securing the Use of AI in Payment Environments** | Published 2025 (September per most sources) | High-level principles: AI systems in payment environments must be deployed and managed in line with PCI requirements |
| **Additional guidance on securing AI in payment environments ("Security Considerations for AI Systems")** | Reported October 2026 (single source; verify) | Protecting data given to AI systems, defending against AI-assisted attacks, and human approval of AI agent actions involving cardholder data |
| **Information Supplement: Protecting Telephone-Based Payment Card Data** | Current version verify | Telephone payments, DTMF masking and suppression, scope reduction, "DTMF bleed" |

**Key PCI DSS requirements applied to virtual agents**

| Requirement | Application |
|---|---|
| Req. 3: never store sensitive authentication data after authorization; render stored PAN unreadable; mask display (first six and last four at most) | No card security code in recordings, transcripts, prompts, vector stores, logs or vendor copies; redact card numbers before they reach the model |
| Req. 4: strong cryptography in transit | TLS for chat, APIs, webhooks and model calls; SRTP for voice; no card data by SMS or email |
| Req. 6: secure development and change control | Prompt, flow and model changes under change control; testing of the bot and plugins; protections for public-facing web apps |
| Req. 7 and 8: least privilege and MFA | Bot service accounts and human agents limited; MFA into the cardholder data environment |
| Req. 10: logging and monitoring | Tool calls and access logged; logs themselves free of card data |
| Req. 11: testing | Penetration testing including AI-specific attacks on in-scope components |
| Req. 12.8 and 12.9: third-party service providers | Written responsibility split with model, telephony, speech and analytics vendors; their attestations reviewed |
| Scope reduction (common practice) | Hand payment to a validated payment page or IVR with DTMF masking so the agent never hears or sees card data; confirm with a QSA |

## 3.2 HIPAA and health-care AI

| Standard or rule | Status | What it requires for virtual agents |
|---|---|---|
| **HIPAA Privacy Rule** (45 CFR Part 164 Subpart E) | In force | Minimum necessary; identity verification before disclosure; patient authorization for marketing; rules for family members and personal representatives |
| **HIPAA Security Rule** (Subpart C) | In force; overhaul proposed January 6, 2025 (mandatory encryption and MFA, removal of "addressable" specifications, annual risk analysis including AI); final status not confirmed | Risk analysis covering the bot; access control; audit logs; integrity; encryption; contingency plans |
| **Breach Notification Rule** (Subpart D) | In force | Notice to individuals and HHS within 60 days; misdirected messages are a test scenario |
| **Business associate agreements** | In force | A BAA with every vendor that creates, receives, maintains or transmits PHI for the agent (model, speech, telephony, orchestration, analytics, logging, vector database); consumer AI products are usually not covered |
| OCR guidance on online tracking technologies | Guidance; the "Proscribed Combination" portion was vacated in *American Hospital Association v. Becerra* (N.D. Tex., June 2024), HHS withdrew its appeal in August 2024, and the rest remains | Chat widgets must not send PHI to ad or analytics vendors without a BAA or authorization |
| **Section 1557, 45 CFR 92.210** | In force (compliance reported due May 1, 2025) | Identify and mitigate discrimination risk from patient-care decision-support tools, including vendor tools |
| **ONC HTI-1, 45 CFR 170.315(b)(11)** | In force | Certified health IT must support decision-support interventions with source attributes (expanded for predictive interventions trained on data) and risk-management information |
| **CMS Medicare Advantage rule (CMS-4201-F) and February 6, 2024 FAQ** | In force | AI may assist coverage decisions but must consider individual circumstances; length-of-stay predictions alone cannot end post-acute care; no criteria beyond CMS rules; guard against bias |
| **FDA clinical decision support and general wellness guidance** | Final guidance January 2026 | Determines when AI health software is a regulated device |
| 42 CFR Part 2 | In force | Substance-use treatment records |
| State health-data laws (for example Washington My Health My Data Act; California CMIA; state AI-in-utilization-review laws) | In force | Consent and use limits beyond HIPAA, sometimes with private rights of action |
| **HITRUST AI Security Assessment and Certification** | Available since late 2024 (month varies by source) | Up to 44 AI-specific security controls; can be paired with e1, i1 or r2 assessments (whether it can stand alone is described inconsistently; verify); separate AI Risk Management Assessment |
| Joint Commission and Coalition for Health AI guidance on responsible AI use | Guidance (2025; verify) | Governance, monitoring and transparency for hospital AI |

## 3.3 Financial services and insurance

| Standard or rule | Status | What it requires |
|---|---|---|
| **Interagency model risk guidance (SR 26-2; OCC Bulletin 2026-13; FDIC FIL-15-2026)** | Issued April 17, 2026, superseding SR 11-7 | Principles-based model risk management; reported to place generative AI and agents outside its scope, with an AI request for information planned; inventories, validation and monitoring remain good practice |
| Interagency third-party risk management guidance (2023) | In force; principles-based replacement proposed September 2026 (OCC Bulletin 2026-46, verify) | Due diligence, contracts, monitoring and exit plans for AI vendors |
| **ECOA / Regulation B adverse-action notices; CFPB Circulars 2022-03 and 2023-03** | Statute and regulation in force; circulars' status after the CFPB guidance review verify | Specific, accurate reasons for adverse credit decisions, even when AI is used |
| CFPB issue spotlight "Chatbots in Consumer Finance" | Guidance (June 2023) | Chatbots must not trap consumers, give inaccurate information or miss disputes; liability under federal consumer financial law |
| UDAAP; FCRA; GLBA Safeguards Rule | In force | Fair and accurate communications; consumer-report accuracy; security program |
| FINRA Regulatory Notice 24-09 (generative AI) | Guidance (verify current text) | Supervision, communications and recordkeeping duties apply to AI tools |
| SEC books-and-records and marketing rules | In force; the SEC withdrew its predictive data analytics proposal on June 12, 2025 | Retain and supervise bot communications; substantiate AI claims |
| **NYDFS Part 500 (cybersecurity) and October 2024 industry letter on AI cybersecurity risks** | Regulation in force; letter is guidance (verify) | AI-enabled social engineering, AI vendor risk and data protection within the cybersecurity program |
| **NAIC Model Bulletin on insurers' use of AI** | Adopted by about 24 to 25 states plus D.C. | AI governance program, risk management, vendor oversight, documentation on request |
| NYDFS Insurance Circular Letter No. 7 (2024) on AI and external data | Guidance (verify) | Fairness testing and governance for insurers' AI and external data |
| EU DORA; EBA and EIOPA guidance; Consumer Credit Directive 2 | In force or applying (CCD2 from November 20, 2026) | ICT risk, third-party oversight, human review of automated credit assessments |
| UK FCA Consumer Duty and SM&CR | In force | Good outcomes and senior-manager accountability for AI |

## 3.4 Security, privacy and AI management standards

| Standard or framework | Type | What it covers for virtual agents |
|---|---|---|
| **ISO/IEC 42001** (AI management system) | Certifiable standard | AI policy, roles, risk and impact assessment, lifecycle controls, supplier oversight; maps to ISO/IEC 27001 and 27701 |
| ISO/IEC 23894 (AI risk management) | Guidance standard | Risk-management process for AI |
| ISO/IEC 42005 (AI system impact assessment) | Guidance standard (verify publication) | Assessing impacts on individuals and society |
| ISO/IEC 27001, 27701, 27017, 27018 | Certifiable / guidance | Information security, privacy and cloud controls for the bot platform |
| **SOC 2** (AICPA Trust Services Criteria) | Attestation | Security, availability, confidentiality, processing integrity and privacy, increasingly interpreted to cover AI controls |
| **NIST AI Risk Management Framework and AI 600-1 Generative AI Profile** | Voluntary framework | Govern, map, measure, manage; generative-AI risks and actions including red teaming; referenced as a defense in some state laws (Texas, Colorado) |
| NIST AI 100-2 (adversarial machine-learning taxonomy) | Guidance | Attack taxonomy, including prompt injection |
| NIST control overlays for securing AI systems (SP 800-53 based) | In development (verify) | AI-specific security controls |
| NIST AI Agent Standards Initiative (February 2026) | Initiative (verify) | Agent identity, authorization and security standards |
| **OWASP Top 10 for LLM Applications (2025)** and **Top 10 for Agentic Applications (2026)** | Community standards | Prompt injection, sensitive-data disclosure, excessive agency, unbounded consumption, memory poisoning, agent supply chain |
| MITRE ATLAS | Threat matrix | Adversary tactics against AI systems |
| **UK AI Cyber Security Code of Practice (January 31, 2025)** and **ETSI TS 104 223 / TR 104 128** | Voluntary code and technical standard | 13 principles for secure design, development, deployment, maintenance and end-of-life of AI |
| Cloud Security Alliance AI Controls Matrix | Control framework (verify current version) | Cloud and AI control catalog |
| EU AI Act harmonised standards (CEN-CENELEC JTC 21) | In development | Will give presumption of conformity for high-risk duties |
| Singapore Model AI Governance Framework for Agentic AI (January 22, 2026) | Voluntary | Bounding agent risks, human accountability, technical controls, human approval at irreversible steps |

## 3.5 Telecom and messaging

| Standard or rule | What it requires for virtual agents |
|---|---|
| STIR/SHAKEN (FCC) | Authenticated caller ID for outbound calls |
| CTIA Messaging Principles and Best Practices | Opt-in, STOP and HELP handling, content limits for business texting |
| 10DLC / A2P registration (The Campaign Registry) | Brand and campaign registration; reported 2026 checks on EIN age and opt-in URLs; privacy-policy and terms URLs required by some carriers' platforms from June 30, 2026 |
| Reassigned Numbers Database (FCC) | Check before calling to avoid calling a number's new owner |
| UK Ofcom General Conditions and persistent-misuse policy; TPS and CTPS | Valid caller ID, silent and abandoned call limits, preference-service screening |

## 3.6 Accessibility

| Standard | Status | Application |
|---|---|---|
| WCAG 2.2 AA | Current W3C recommendation; WCAG 2.1 AA is the legal baseline for the DOJ Title II rule | Chat widgets, streaming replies, keyboard and screen-reader support |
| EN 301 549 | EU and UK public procurement standard | ICT accessibility including two-way voice communication |
| Section 508 | US federal | Federal agencies and their vendors |
| European Accessibility Act | Applies since June 28, 2025 | Accessible customer-service channels |

## 3.7 Content provenance

| Standard | Status | Application |
|---|---|---|
| C2PA / Content Credentials | Industry standard; adoption uneven, audio validation emerging (2026) | Machine-readable provenance for generated media; metadata stripping is a known weakness |
| EU Code of Practice on marking and labelling AI-generated content | Voluntary (June 2026) | Route to EU AI Act Article 50 compliance |
| California AI Transparency Act | In force August 2, 2026 | Detection tools and provenance for covered providers |

## 3.8 Crosswalk: control areas and the standards that require them

| Control area | PCI DSS | HIPAA | Financial | ISO/IEC 42001 and 27001 | NIST AI RMF | OWASP | Laws in Part 1 |
|---|---|---|---|---|---|---|---|
| Keep regulated data out of the model path | Req. 3, scope reduction | Minimum necessary; BAA scope | GLBA | Data controls | Map, Manage | LLM02 | GDPR, state privacy laws |
| Vendor and model-provider oversight | Req. 12.8, 12.9 | BAAs | Third-party guidance, DORA | Supplier controls | Govern | Supply chain | AI Act deployer duties |
| Access control and least privilege for agents | Req. 7, 8 | Security Rule | Part 500 | Access control | Manage | Excessive agency | |
| Logging and auditability | Req. 10 | Audit controls | Books and records | Logging | Measure | | AI Act logging, ADMT rules |
| Testing and red teaming | Req. 6, 11 | Risk analysis | Model validation | Verification | Measure | All | TRAIGA defense, AI Act |
| Human oversight and review | PCI AI guidance on agent actions | CMS, Section 1557 | ECOA, CCD2 | Human oversight | Govern | Excessive agency | GDPR Art. 22, UK 22A to 22D, CA AB 1609 |
| Transparency and disclosure | | | UDAAP | Transparency | Govern | | AI Act Art. 50, state bot laws |
| Incident response and reporting | Incident response | Breach notification | Part 500 notice | Incident management | Manage | | GDPR, CRA, state breach laws |
| Fairness and non-discrimination | | Section 1557 | ECOA, NAIC | Impact assessment | Measure | | NYC LL 144, Illinois, Colorado |
| Accessibility | | | | | | | ADA, EAA, Equality Act |

---

# Part 4. Open items to verify

| # | Item | Where |
|---|---|---|
| 1 | Federal Register date of the FCC September 30, 2026 revocation order | 1.4 |
| 2 | Text and thresholds of California AB 1609; scope for enterprise contact centers | 1.2 |
| 3 | New York S9051-B effective date; Washington HB 2225 scope for customer-service bots | 1.2 |
| 4 | 2026 chatbot laws in Connecticut, Georgia, Idaho, Iowa, Nebraska, Oregon, Rhode Island and Tennessee | 1.2 |
| 5 | Colorado AI Act litigation outcome; SB 26-189 text | 1.2 |
| 6 | Local laws: NYC biometric law, Portland ban, government facial-recognition bans | 1.1 |
| 7 | Comprehensive-privacy and all-party-consent state lists | 1.3 |
| 8 | Executive-order history and OMB memoranda | 1.4 |
| 9 | EU Omnibus high-risk dates; AI Liability Directive withdrawal; member-state laws (Germany, Denmark, Spain) | 1.5, 1.6 |
| 10 | UK DMCC fining level; Ofcom abandoned-call thresholds; accessibility regulation standard | 1.7 |
| 11 | Case statuses: Raine, Otter.ai, Wolf River, Starbuck v. Google, Mobley, Harper, Lokken, Kisting-Leung, Barrows, Clearview appeals, Thomson Reuters v. Ross appeal, GEMA appeal, NYT MDL | Part 2 |
| 12 | Background-only cases: SCHUFA holding, Uber Amsterdam, SyRI, Rite Aid, Dutch Clearview fine | Part 2 |
| 13 | PCI "Security Considerations for AI Systems" document and the telephone-payments supplement version | 3.1 |
| 14 | HIPAA Security Rule final status; HITRUST standalone option; Joint Commission/CHAI guidance | 3.2 |
| 15 | CFPB circular status; FINRA 24-09; NYDFS AI letter and Circular Letter 7 | 3.3 |
| 16 | ISO/IEC 42005 publication; NIST overlays; CSA AI Controls Matrix version | 3.4 |

---

# Part 5. Sources

**Part 1 (laws and regulations):** [Fox Rothschild: California AB 1609](https://dataprivacy.foxrothschild.com/2026/09/articles/general-privacy-data-security-news-developments/5118/) · [Governor of California: September 28, 2026 signings](https://www.gov.ca.gov/2026/09/28/governor-newsom-signs-commonsense-legislation-to-make-your-life-easier/) · [WSGR: California 2026 privacy and AI bills](https://www.wsgr.com/en/insights/california-enacts-over-two-dozen-key-privacy-and-ai-bills-into-law-in-2026-legislative-session.html) · [CHCF: California health-care AI bills](https://www.chcf.org/blog/2026/10/08/newsom-approves-3-health-care-ai-bills-vetoes-2/) · [CASRAI: SB 942 effective August 2026](https://www.casrai.org/news/california-sb-942-ai-transparency-act-effective-august-2026) · [Hunton: CCPA staggered deadlines](https://www.hunton.com/privacy-and-cybersecurity-law-blog/newly-approved-ccpa-regulations-have-staggered-deadlines-for-compliance) · [Norton Rose Fulbright: Colorado AI law](https://www.nortonrosefulbright.com/en-us/knowledge/publications/18733d31/colorado-enacts-revised-ai-law) · [Akin: New York S9051-B](https://www.akingump.com/en/insights/ai-law-and-regulation-tracker/new-york-enacts-prohibition-on-unsafe-ai-companion-features-for-minors-s9051-b) · [Hunton: Washington HB 2225](https://hunton.com/privacy-and-cybersecurity-law-blog/washington-state-enacts-law-regulating-ai-companion-chatbots-with-private-right-of-action) · [Orrick: 2026 state chatbot laws](https://www.orrick.com/en/Insights/2026/04/2026-State-Chatbot-Laws-Key-Provisions-and-Regulatory-Trends) · [Transparency Coalition: 14 new state chatbot laws](https://www.transparencycoalition.ai/news/watershed-year-for-chatbot-safety-measures-14-new-state-laws-enacted-so-far-in-2026) · [Davis Polk: Utah AI law amendments](https://davispolk.com/insights/client-update/utah-scales-back-reach-generative-ai-consumer-protection-law) · [Oregon Legislature: HB 3865](https://apps.oregonlegislature.gov/liz/2025R1/Downloads/MeasureDocument/HB3865/B-Engrossed) · [KALB: Louisiana AI call disclosure bill](https://www.kalb.com/2026/04/08/louisiana-lawmakers-advance-bill-requiring-ai-disclosure-campaign-robocalls/) · [DCI: NYC Local Law 144 audit](https://blog.dciconsult.com/recommended-changes-to-local-law-144) · [FCC: AI-generated voices in robocalls](https://www.fcc.gov/document/fcc-makes-ai-generated-voices-robocalls-illegal) · [Inside Global Tech: FCC revocation order](https://www.insideglobaltech.com/2026/10/02/update-fcc-adopts-final-order-and-further-notice-on-tcpa-consent-revocation/) · [Orrick: revoke-all deferral](https://infobytes.orrick.com/2026-01-16/fcc-extends-robocall-consent-revocation-rule-waiver-to-january-2027/) · [FTC: TAKE IT DOWN Act enforcement](https://www.ftc.gov/news-events/news/press-releases/2026/05/ftc-begins-enforcing-take-it-down-act) · [Federal Register: amended COPPA Rule](https://www.federalregister.gov/documents/2025/04/22/2025-05904/childrens-online-privacy-protection-rule) · [Cooley: CFPB adverse-action circular](https://www.cooley.com/news/insight/2023/2023-09-25-cfpb-mandates-additional-specificity-in-adverse-action-communications-based-on-ai-or-complex-credit-models) · [Global Policy Watch: GUARD Act](https://www.globalpolicywatch.com/2026/05/senate-judiciary-committee-advances-guard-act-regulating-minor-use-of-ai/) · [CASRAI: federal preemption](https://casrai.org/news/federal-ai-moratorium-state-preemption-fight-2026) · [Lawfare: AI preemption EO and BEAD](https://www.lawfaremedia.org/article/the-ai-preemption-executive-order-s-bead-strategy-faces-steep-legal-hurdles) · [Garrigues: AI Digital Omnibus published](https://www.garrigues.com/en_GB/garrigues-digital/ai-digital-omnibus-regulation-has-been-published-redefining-deadlines-and) · [Jones Day: Code of Practice on labelling](https://www.jonesday.com/en/insights/2026/06/european-commission-publishes-final-code-of-practice-on-marking-and-labelling-aigenerated-content) · [DPO AS: Council Digital Omnibus mandate](https://dpoas.co.il/blog/digital-omnibus-council-mandate-gdpr/) · [Taylor Wessing: Digital Fairness Act](https://www.taylorwessing.com/en/insights-and-events/insights/2026/10/eu-digital-fairness-act-dark-patterns-and-addictive-designs) · [European Commission: consumer credit](https://commission.europa.eu/topics/consumers/consumer-rights-and-complaints/consumer-financial-products-and-services/consumer-protection-financial-services_en) · [Ius Laboris: Platform Work Directive transposition](https://www.iuslaboris.com/insights/eu-platform-work-directive-which-countries-have-implemented/) · [McCann FitzGerald: CRA reporting](https://www.mccannfitzgerald.com/knowledge/data-privacy-and-cyber-risk/cyber-resilience-act-reporting-obligations-apply-from-11-september-2026) · [ENISA: CRA Single Reporting Platform](https://www.enisa.europa.eu/cra-srp/) · [Cleary Gottlieb: Italy's AI law](https://www.clearygottlieb.com/news-and-insights/publication-listing/italy-adopts-the-first-national-ai-law-in-europe-complementing-the-eu-ai-act.) · [A&O Shearman: UK DUAA in force](https://www.aoshearman.com/en/insights/ao-shearman-on-data/key-data-protection-changes-under-the-data-use-and-access-act-2025-comes-into-force) · [Mishcon de Reya: PECR fines and cookies](https://www.mishcon.com/news/unlawful-cookies-a-new-avenue-for-the-ico-to-issue-fines) · [RPC: Ofcom explainer on AI chatbots](https://www.rpclegal.com/snapshots/technology-digital/spring-2026/ofcom-publishes-an-explainer-on-the-regulation-of-ai-chatbots-under-the-online-safety-act/) · [IAPP: King's Speech, no AI bill](https://iapp.org/news/a/king-s-speech-signals-diffuse-uk-digital-policy-agenda-but-no-ai-bill) · [Inside Global Tech: UK financial regulators and AI](https://www.insideglobaltech.com/2026/04/09/uk-financial-services-regulators-approach-to-artificial-intelligence-in-2026/) · [GOV.UK: Report on Copyright and AI](https://assets.publishing.service.gov.uk/media/69ba692226909a14239612e4/CP2602959_-_Report_on_Copyright_and_Artificial_Intelligence_web.pdf)

**Part 2 (cases):** [Torkin Manes: Moffatt v. Air Canada](https://www.torkin.com/insights/publication/bc-tribunal-confirms-companies-remain-liable-for-ai-chatbot-created-information) · [ASIS: German court holds Google liable](https://www.asisonline.org/security-management-magazine/latest-news/today-in-security/2026/june/incorrect-AI-liability/) · [Haynes Boone: defamation in the AI age](https://www.haynesboone.com/news/articles/defamation-in-the-ai-age) · [Benesch: first wave of AI defamation cases](https://www.beneschlaw.com/insight/when-chatgpt-lies-what-the-first-wave-of-ai-defamation-cases-means-for-plaintiffs/) · [CourtDocket: Garcia v. Character.AI](https://courtdocket.org/garcia-v-character-ai-lawsuit-first-amendment-ruling-and-settlement/) · [Goodwin: Ambriz v. Google and CIPA](https://www.goodwinlaw.com/en/insights/publications/2025/02/alerts-practices-dpc-ftec-ai-voice-products-subject-to-california-invasion-of-privacy-claims) · [Maine Law: Ambriz, Popa and standing](https://sjipl.mainelaw.maine.edu/2025/12/18/the-collapse-of-capability-theory-ambriz-popa-and-the-future-of-article-iii-standing-in-ai-privacy-cases/) · [ZwillGen: Otter.ai litigation](https://www.zwillgen.com/litigation/first-major-ai-meeting-assistant-lawsuit-practical-lessons-otter-ai-litigation/) · [Keker: Dialpad CIPA ruling](https://www.keker.com/news/news-items/s-f-court-rejects-claims-that-dialpad-s-ai-enhancements-violate-wiretapping-law) · [Tech Policy Press: Meta Texas settlement](https://techpolicy.press/meta-settles-texas-biometric-data-lawsuit) · [Fox 7: Google Texas settlement](https://www.fox7austin.com/news/google-texas-lawsuit-settlement-may-2025) · [ICO: Upper Tribunal judgment on Clearview](https://ico.org.uk/about-the-ico/media-centre/news-and-blogs/2025/10/uk-upper-tribunal-hands-down-judgment-on-clearview-ai-inc) · [GOV.UK: ICO v. Clearview [2025] UKUT 319](https://www.gov.uk/administrative-appeals-tribunal-decisions/the-information-commissioners-office-v-clearview-ai-inc-privacy-international-intervening-2025-ukut-319-aac) · [SCL: CJEU on explanations of automated credit decisions](https://www.scl.org/cjeu-rules-that-data-subjects-are-entitled-to-explanations-of-automated-credit-decisions/) · [CURIA press release C-203/22](https://curia.europa.eu/jcms/upload/docs/application/pdf/2025-02/cp250022en.pdf) · [EDPB: Replika fine](https://www.edpb.europa.eu/news/ai-the-italian-supervisory-authority-fines-company-behind-chatbot-replika_ga) · [Digital Policy Alert: OpenAI fine annulled](https://digitalpolicyalert.org/event/38611-italian-court-cancelled-eur-15-million-italian-data-protection-authority-fine-against-openai) · [WBUR: Kramer fine](https://www.wbur.org/news/2024/09/27/steve-kramer-biden-robocalls-fines) · [Infosecurity: Lingo Telecom](https://www.infosecurity-magazine.com/news/lingo-telecom-fine-1m-fake-joe/) · [TCPAWorld: Aidvantage settlement](https://tcpaworld.com/2026/08/05/tcpa-advantage-aiadvatage-to-settle-tcpa-class-action-for-3000000-00/) · [Norton Rose Fulbright: EEOC iTutorGroup settlement](https://nortonrosefulbright.com/en/knowledge/publications/2ec12415/us-eeocs-first-settlement-in-ai-hiring-discrimination) · [Akin: Mobley v. Workday](https://www.akingump.com/en/insights/ai-law-and-regulation-tracker/court-allows-discrimination-claims-against-ai-hiring-tool-to-proceed-or-mobley-v-workday-inc) · [Epstein Becker Green: Harper v. Sirius XM](https://www.ebglaw.com/workforce-bulletin/artificial-intelligence-bias-harper-v-sirius-xm-challenges-algorithmic-discrimination-in-hiring) · [HR Dive: Sirius XM dismissal](https://www.hrdive.com/news/sirius-xm-beats-allegations-of-ai-fueled-racial-bias/832115/) · [HR Dive: ACLU complaint against Intuit and HireVue](https://www.hrdive.com/news/ai-intuit-hirevue-deaf-indigenous-employee-discrimination-aclu/743273/) · [AFS Law: discovery against UHC](https://www.afslaw.com/perspectives/alerts/federal-court-orders-broad-discovery-against-uhc-ai-coverage-denial-lawsuit) · [Radiology Business: Cigna lawsuit](https://radiologybusiness.com/topics/healthcare-management/healthcare-economics/cigna-violated-law-denying-claims-imaging-and-other-services-bulk-lawsuit-alleges) · [CASRAI: AI-washing enforcement record](https://casrai.org/guides/ai-washing-enforcement-sec-ftc-record) · [O'Melveny: SEC AI-washing charges](https://omm.com/insights/alerts-publications/sec-targets-ai-washing-in-charges-against-two-investment-advisers) · [PYMNTS: FTC and Air AI](https://www.pymnts.com/legal/2026/ftc-seeks-to-ban-air-ai-from-marketing-business-opportunities/) · [JD Supra: Texas generative AI settlement](https://production.jdsupra.com/legalnews/the-eyes-of-texas-are-on-ai-generative-6527212) · [Jurist: Anthropic settlement approved](https://www.jurist.org/news/2026/07/judge-approves-record-1-5-billion-settlement-involving-anthropic/) · [Norton Rose Fulbright: AI copyright cases in 2026](https://www.nortonrosefulbright.com/en/knowledge/publications/ce8eaa5f/ai-in-litigation-series-an-update-on-ai-copyright-cases-in-2026) · [AI Lawsuit Tracker: rulings](https://ailawsuittracker.com/rulings/) · [UK Judiciary: Getty Images v. Stability AI](https://www.judiciary.uk/judgments/getty-images-and-others-v-stability-ai/) · [Cleary Gottlieb: Getty v. Stability](https://www.clearygottlieb.com/news-and-insights/publication-listing/uk-high-court-issues-landmark-ruling-in-getty-images-v-stability-ai) · [SCOTUSblog: Thaler v. Perlmutter](https://www.scotusblog.com/cases/thaler-v-perlmutter/) · [Loeb & Loeb: Lehrman v. Lovo](https://www.loeb.com/en/insights/publications/2025/07/lehrman-v-lovo-inc) · [Linklaters: Ayinde judgment](https://www.linklaters.com/insights/blogs/digilinks/2025/june/ai---check-your-cites---ayinde-judgement) · [OECD AI incidents: Zhang v. Chen](https://oecd.ai/en/incidents/2024-02-26-9c91) · [Law Times: CAD 31,150 costs](https://www.lawtimesnews.com/resources/professional-regulation/lawyer-who-used-ai-fabricated-citations-hit-with-31150-in-costs-to-lso/393407) · [CTV: AI citations in Canadian courts](https://www.ctvnews.ca/sci-tech/article/ai-fabricated-legal-citations-in-canadian-courts-tip-of-the-iceberg-expert-warns/) · [UC Strategies: 2026 AI hallucination fines](https://ucstrategies.com/news/courts-fined-lawyers-145k-for-ai-hallucinations-in-q1-alone/)

**Part 3 (standards):** [PCI SSC: integrating AI in PCI assessments](https://blog.pcisecuritystandards.org/new-guidance-integrating-artificial-intelligence-into-pci-assessments) · [PCI SSC: guidance on securing AI in payment environments](https://www.pcisecuritystandards.org/about_us/press_releases/pci-ssc-publishes-additional-guidance-on-securing-ai-in-payment-environments/) · [Help Net Security: PCI SSC human approval for AI agent actions](https://helpnetsecurity.com/2026/10/09/pci-ssc-payment-environments-ai-security-guidance) · [Barr Advisory: is AI in scope for PCI DSS](https://www.barradvisory.com/resource/ai-scope-pci-dss/) · [Call Centre Helper: telephone payments guidance](https://www.callcentrehelper.com/new-guidance-secure-telephone-payments-140960.htm) · [MoFo: HHS withdraws tracking appeal](https://www.mofo.com/resources/insights/240930-a-mofo-privacy-minute-q-a-hhs-withdraws) · [Crowell: Section 1557 decision-support tools](https://www.crowell.com/en/insights/client-alerts/hhs-applies-discrimination-prohibitions-to-use-of-automated-and-non-automated-patient-care-decision-support-tools) · [Drummond Group: HTI-1 final rule](https://www.drummondgroup.com/blog/analyzing-hti-1-final-rule/) · [Norton Rose Fulbright: CMS on AI in MA coverage](https://www.nortonrosefulbright.com/en/knowledge/publications/644bd9a2/cms-clarifies-medicare-advantage-organizations-use-of-ai-and-algorithms-in-coverage-decisions) · [Arnold & Porter: FDA CDS guidance 2026](https://www.arnoldporter.com/en/perspectives/advisories/2026/01/fda-cuts-red-tape-on-clinical-decision-support-software) · [HITRUST: AI Security Assessment](https://hitrustalliance.net/blog/building-trust-in-ai-introducing-the-hitrust-ai-security-assessment-and-certification) · [Sullivan & Cromwell: revised model risk guidance](https://www.sullcrom.com/insights/memo/2026/April/OCC-Fed-FDIC-Issue-Revised-Guidance-Model-Risk-Management) · [CFPB: Chatbots in consumer finance](https://consumerfinance.gov/data-research/research-reports/chatbots-in-consumer-finance/chatbots-in-consumer-finance) · [Paul Hastings: SEC withdraws 14 proposals](https://www.paulhastings.com/insights/client-alerts/sec-withdraws-14-pending-rule-proposals) · [Quarles: NAIC bulletin adoption](https://quarles.com/newsroom/publications/nearly-half-of-states-have-now-adopted-naic-model-bulletin-on-insurers-use-of-ai) · [GOV.UK: AI Cyber Security Code of Practice](https://www.gov.uk/government/publications/ai-cyber-security-code-of-practice) · [Hunton: UK AI cyber security code](https://hunton.com/privacy-and-information-security-law/uk-publishes-ai-cyber-security-code-of-practice-and-implementation-guide) · [Knowlee: ISO 27001, 42001, SOC 2 and AI Act crosswalk](https://www.knowlee.ai/blog/ai-security-compliance-framework-2026) · [Baker McKenzie: Singapore agentic AI framework](https://www.bakermckenzie.com/en/insight/publications/2026/01/singapore-governance-framework-for-agentic-ai-launched) · [Twilio: 10DLC privacy policy requirement](https://static1.twilio.com/en-us/changelog/a2p-10dlc-campaign-registration-will-require-privacy-policy-and-) · [Content Authenticity Initiative: state of content authenticity 2026](https://contentauthenticity.org/blog/the-state-of-content-authenticity-in-2026)
