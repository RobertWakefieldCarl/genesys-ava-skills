#!/usr/bin/env node
/**
 * AVA compliance report: merges scorecard.json with evidence-map.json
 * (derived solely from assets/AI_and_Virtual_Agent_Laws_Cases_and_Compliance_Standards.md).
 *
 * Usage:
 *   node generate-compliance-report.js --scorecard <post-mitigation scorecard.json> [options]
 *
 * Options:
 *   --baseline-scorecard <path>   Prior run for before/after (retest verification)
 *   --mitigations <path>          JSON describing fixes applied (optional)
 *   --output-html <filename>      Default: compliance-report.html or compliance-verification-report.html
 *
 * Outputs: compliance-report.html (or verification name); compliance-report.pdf (if Puppeteer available).
 */

const fs = require('fs');
const path = require('path');

function parseArgs() {
  const argv = process.argv.slice(2);
  const out = {
    scorecard: null,
    baselineScorecard: null,
    mitigations: null,
    outputHtml: null,
    outDir: process.cwd(),
    evidenceMap: null,
    themesFrom: 'all',
    deployment: 'commercial',
    pdf: true,
  };
  for (let i = 0; i < argv.length; i++) {
    if (argv[i] === '--scorecard' && argv[i + 1]) out.scorecard = path.resolve(argv[++i]);
    else if (argv[i] === '--baseline-scorecard' && argv[i + 1]) out.baselineScorecard = path.resolve(argv[++i]);
    else if (argv[i] === '--mitigations' && argv[i + 1]) out.mitigations = path.resolve(argv[++i]);
    else if (argv[i] === '--output-html' && argv[i + 1]) out.outputHtml = argv[++i];
    else if (argv[i] === '--out-dir' && argv[i + 1]) out.outDir = path.resolve(argv[++i]);
    else if (argv[i] === '--evidence-map' && argv[i + 1]) out.evidenceMap = path.resolve(argv[++i]);
    else if (argv[i] === '--themes-from' && argv[i + 1]) out.themesFrom = argv[++i];
    else if (argv[i] === '--deployment' && argv[i + 1]) out.deployment = argv[++i].toLowerCase();
    else if (argv[i] === '--no-pdf') out.pdf = false;
  }
  return out;
}

/** FedRAMP / §3.10 controls apply only when deployment is us-government. */
function filterEvidenceMapForDeployment(evidenceMap, deployment) {
  const profiles = evidenceMap.deployment_profiles || {};
  const profile = profiles[deployment];
  if (!profile && deployment !== 'commercial' && deployment !== 'us-government') {
    throw new Error(
      `Unknown --deployment "${deployment}". Use commercial (default) or us-government.`
    );
  }
  const controls = (evidenceMap.controls || []).filter((c) => {
    const applies = c.applies_to && c.applies_to.length ? c.applies_to : ['all'];
    if (applies.includes('all')) return true;
    return applies.includes(deployment);
  });
  return { ...evidenceMap, controls, _activeDeployment: deployment };
}

function escapeHtml(s) {
  if (s == null) return '';
  return String(s)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;');
}

function loadJson(p) {
  return JSON.parse(fs.readFileSync(p, 'utf8'));
}

const skillDir = path.resolve(__dirname, '..');
const defaultEvidenceMap = path.join(skillDir, 'data', 'evidence-map.json');

function collectTextFromAttempt(attempt) {
  const parts = [];
  if (!attempt || typeof attempt !== 'object') return '';
  const layer2 = attempt.layer2;
  if (Array.isArray(layer2)) {
    for (const row of layer2) {
      if (row.evidence) parts.push(row.evidence);
      if (row.reason) parts.push(row.reason);
      if (row.assertion) parts.push(row.assertion);
    }
  }
  if (attempt.guardrailViolations && Array.isArray(attempt.guardrailViolations)) {
    parts.push(...attempt.guardrailViolations.map((g) => String(g)));
  }
  return parts.join(' \n ');
}

// Keywords are matched at a word start, so stems still match their inflections
// ("diagnos" -> "diagnosis") without matching mid-word ("age" -> "message", "coverage").
const keywordRe = new Map();
function matchesKeyword(textLower, kw) {
  const k = kw.toLowerCase();
  let re = keywordRe.get(k);
  if (!re) {
    re = new RegExp('(^|[^a-z0-9])' + k.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
    keywordRe.set(k, re);
  }
  return re.test(textLower);
}

function matchControls(textLower, controls) {
  const hits = [];
  for (const c of controls) {
    for (const kw of c.keywords || []) {
      if (matchesKeyword(textLower, kw)) {
        hits.push(c);
        break;
      }
    }
  }
  return hits;
}

function uniqById(controls) {
  const seen = new Set();
  return controls.filter((c) => {
    if (seen.has(c.id)) return false;
    seen.add(c.id);
    return true;
  });
}

function buildRows(scData, evidenceMap, themesFrom = 'all') {
  const controls = evidenceMap.controls || [];
  const perScenario = scData.perScenario || [];
  const rows = [];

  for (const scenario of perScenario) {
    const attempts = scenario.attempts || [];
    let worstVerdict = scenario.verdict || scenario.classification || '';
    const scenarioText = [
      scenario.name,
      scenario.testCaseId,
      ...attempts.map(collectTextFromAttempt),
    ]
      .filter(Boolean)
      .join(' \n ')
      .toLowerCase();

    const failedChecks = [];
    for (const att of attempts) {
      const layer2 = att.layer2 || [];
      for (const row of layer2) {
        const v = (row.verdict || '').toLowerCase();
        if (v && v !== 'pass' && v !== 'n/a') {
          failedChecks.push({
            dimension: row.dimension || '—',
            id: row.id || '—',
            verdict: row.verdict,
            reason: row.reason || row.evidence || '',
            assertion: row.assertion || '',
          });
        }
      }
    }

    const matched = uniqById(matchControls(scenarioText, controls));
    const failContext = failedChecks
      .map((f) => [f.reason, f.assertion].filter(Boolean).join(' — '))
      .join(' \n ');
    // 'all' (default) matches the whole scenario corpus, including passing checks, so a theme
    // means "this scenario touches this topic". 'failures' matches only failing-check text, so a
    // theme means "this failure evidences this concern" — narrower, and the right basis when the
    // report is read as a findings list rather than a coverage map.
    const failMatches = failContext.length > 0 ? matchControls(failContext.toLowerCase(), controls) : [];
    const matchedFromFailures =
      themesFrom === 'failures'
        ? uniqById(failMatches)
        : failContext.length > 0
        ? uniqById([...matched, ...failMatches])
        : matched;

    const overall =
      (scenario.verdict || scenario.classification || '').toLowerCase() === 'pass' ? 'pass' : 'fail';
    const blockingFailed = failedChecks.length > 0;

    rows.push({
      testCaseId: scenario.testCaseId,
      name: scenario.name || scenario.testCaseId,
      overall,
      successRate: scenario.successRate,
      threshold: scenario.threshold,
      worstVerdict,
      failedChecks,
      matchedControls: matchedFromFailures,
      blockingFailed,
    });
  }

  return rows;
}

function rowResultKind(r) {
  const passOk = (r.overall || '').toLowerCase() === 'pass' && !r.blockingFailed;
  if (passOk) return 'pass';
  if (r.blockingFailed) return 'fail';
  return 'review';
}

/** Baseline row by testCaseId for comparison. */
function rowsByTestCaseId(rows) {
  const m = new Map();
  for (const r of rows) {
    const id = r.testCaseId || r.name;
    if (id) m.set(id, r);
  }
  return m;
}

/**
 * Compare baseline vs post rows. Union of testCaseIds from both runs.
 */
function compareRuns(baselineRows, postRows) {
  const baseMap = rowsByTestCaseId(baselineRows);
  const postMap = rowsByTestCaseId(postRows);
  const ids = new Set([...baseMap.keys(), ...postMap.keys()]);
  const rows = [];
  let resolved = 0;
  let regressed = 0;
  let stillFailing = 0;
  let unchangedPass = 0;

  for (const id of ids) {
    const b = baseMap.get(id);
    const p = postMap.get(id);
    const kindB = b ? rowResultKind(b) : 'missing';
    const kindP = p ? rowResultKind(p) : 'missing';

    let delta = '—';
    if (!b && p) delta = 'New in retest';
    else if (b && !p) delta = 'Removed / not in retest';
    else if (kindB === 'fail' || kindB === 'review') {
      if (kindP === 'pass') {
        delta = 'Improved → Pass';
        resolved++;
      } else if (kindP === 'fail') {
        delta = kindB === 'fail' ? 'Still failing' : 'Worsened → Fail';
        stillFailing++;
      } else {
        delta = 'Still not pass (review)';
        stillFailing++;
      }
    } else if (kindB === 'pass') {
      if (kindP === 'pass') {
        delta = 'Still pass';
        unchangedPass++;
      } else if (kindP === 'fail') {
        delta = 'Regressed';
        regressed++;
      } else {
        delta = 'Regressed to review';
        regressed++;
      }
    }

    rows.push({
      testCaseId: id,
      name: (p && p.name) || (b && b.name) || id,
      baseline: b,
      post: p,
      kindB,
      kindP,
      delta,
    });
  }

  rows.sort((a, b) => a.name.localeCompare(b.name));

  return {
    rows,
    counts: { resolved, regressed, stillFailing, unchangedPass, totalCompared: ids.size },
  };
}

function loadMitigationsFile(p) {
  const raw = loadJson(p);
  if (Array.isArray(raw)) return { items: raw, global_notes: [] };
  if (raw && typeof raw === 'object' && Array.isArray(raw.items)) return raw;
  throw new Error('Mitigations JSON must be an array of items or { "items": [...] }');
}

/** Build consolidated mitigation steps by control id (dedupe steps). */
function buildMitigationCatalog(rows) {
  const byId = new Map();
  for (const r of rows) {
    for (const c of r.matchedControls || []) {
      if (!c || !c.id) continue;
      let entry = byId.get(c.id);
      if (!entry) {
        entry = { id: c.id, title: c.title || c.id, steps: [] };
        byId.set(c.id, entry);
      }
      const seen = new Set(entry.steps);
      for (const step of c.remediation || []) {
        const t = String(step).trim();
        if (t && !seen.has(t)) {
          seen.add(t);
          entry.steps.push(t);
        }
      }
    }
  }
  return [...byId.values()].sort((a, b) => a.title.localeCompare(b.title));
}

function computeExecutiveStats(rows, summary) {
  let pass = 0;
  let failDim = 0;
  let review = 0;
  const failedNames = [];
  const themeCounts = new Map();
  let unmapped = 0;

  for (const r of rows) {
    const resultLabel =
      r.overall === 'pass' && !r.blockingFailed ? 'pass' : r.blockingFailed ? 'fail' : 'review';
    if (resultLabel === 'pass') pass++;
    else if (resultLabel === 'fail') {
      failDim++;
      failedNames.push(r.name || r.testCaseId);
    } else review++;

    const mc = r.matchedControls || [];
    if (mc.length === 0) unmapped++;
    for (const c of mc) {
      const id = c.id || c.title;
      themeCounts.set(id, (themeCounts.get(id) || 0) + 1);
    }
  }

  const total = rows.length;
  const pct = total ? Math.round((pass / total) * 100) : 0;
  const topThemes = [...themeCounts.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 8)
    .map(([id, n]) => ({ id, count: n }));

  return {
    total,
    pass,
    failDim,
    review,
    pct,
    failedNames,
    topThemes,
    unmapped,
    summaryPassed: summary.passed,
    summaryTotal: summary.total,
    summaryFailed: summary.failed,
    summaryInfra: summary.infraError,
  };
}

function renderLawThemeCards(matchedControls, evidenceMap) {
  if (!matchedControls || matchedControls.length === 0) {
    return `<p class="muted">No keyword match to the bundled compliance map for this scenario. Review manually against <cite>${escapeHtml(
      evidenceMap.source_bundled || 'the reference document'
    )}</cite>.</p>`;
  }
  let html = '';
  for (const c of matchedControls) {
    html += `<div class="card law-card"><header class="card-h">${escapeHtml(c.title)}</header>`;
    html += '<p class="small-heading">Regulatory / standards (from reference doc)</p><ul>';
    for (const ref of c.regulatory_refs || []) html += `<li>${escapeHtml(ref)}</li>`;
    html += '</ul>';
    if ((c.case_law_refs || []).length) {
      html += '<p class="small-heading">Case law / enforcement (from reference doc)</p><ul>';
      for (const ref of c.case_law_refs) html += `<li>${escapeHtml(ref)}</li>`;
      html += '</ul>';
    }
    html += `<p class="small-heading">Source sections</p><ul>${(c.document_sections || [])
      .map((s) => `<li>${escapeHtml(s)}</li>`)
      .join('')}</ul>`;
    html +=
      '<p class="muted small-note">Mitigation steps for this theme appear in <strong>§ Mitigation catalog</strong> at the end of this report.</p></div>';
  }
  return html;
}

function renderHtml({
  scData,
  evidenceMap,
  rows,
  sourcePath,
  scorecardPath,
  baselineScData,
  baselinePath,
  comparison,
  mitigationsDoc,
  verificationMode,
  activeDeployment,
  deploymentProfiles,
}) {
  const isVerification = !!verificationMode;
  const meta = scData.metadata || {};
  const summary = scData.summary || {};
  const generated = new Date().toISOString();
  const docVersion = evidenceMap.source_document_version || '1.3 (November 2026)';
  const depKey = activeDeployment || 'commercial';
  const depProfile = (deploymentProfiles || {})[depKey] || {
    label: depKey,
    description: '',
  };
  const fedrampNote =
    depKey === 'us-government'
      ? 'FedRAMP, GovRAMP, and Part 3 §3.10 government-cloud controls are <strong>in scope</strong> for this report.'
      : 'FedRAMP and Part 3 §3.10 government-cloud controls are <strong>out of scope</strong> (commercial profile). Use <span class="mono">--deployment us-government</span> for US state or federal government deployments.';
  const mitCatalog = buildMitigationCatalog(rows);
  const exec = computeExecutiveStats(rows, summary);

  const docTitle = isVerification ? 'AVA compliance verification report' : 'AVA compliance assessment report';
  const docSub = isVerification
    ? 'After-mitigation retest compared to baseline; optional recorded fixes and outcome deltas.'
    : 'Mapped evaluation results to the bundled laws, cases, and standards compendium.';

  let mitigationsSectionHtml = '';
  if (mitigationsDoc && (mitigationsDoc.items || []).length > 0) {
    const items = mitigationsDoc.items || [];
    let listHtml = '';
    for (const it of items) {
      const tid = it.test_case_id || it.testCaseId || '';
      const title = it.title || it.summary || 'Mitigation';
      const d = it.description || it.detail || '';
      const areas = Array.isArray(it.areas) ? it.areas.join(', ') : it.areas || '';
      listHtml += `<li class="mit-applied-li">
        <div class="mit-applied-h"><span class="mono">${escapeHtml(tid)}</span> — ${escapeHtml(title)}</div>
        ${d ? `<p class="mit-applied-d">${escapeHtml(d)}</p>` : ''}
        ${areas ? `<p class="muted small-note">Areas: ${escapeHtml(areas)}</p>` : ''}
      </li>`;
    }
    const globals = mitigationsDoc.global_notes || [];
    const gHtml =
      globals.length > 0
        ? `<h3 class="info-h" style="margin-top:0.75rem">General / org-wide</h3><ul>${globals.map((g) => `<li>${escapeHtml(String(g))}</li>`).join('')}</ul>`
        : '';
    mitigationsSectionHtml = `
  <section class="section" aria-labelledby="mit-applied-h">
    <h2 id="mit-applied-h" class="section-head">Mitigations applied</h2>
    <p class="muted">Recorded changes made to the AVA or environment before this retest (from <span class="mono">--mitigations</span> JSON).</p>
    <ol class="mitigations-applied-list">${listHtml}</ol>
    ${gHtml}
  </section>`;
  } else if (isVerification) {
    mitigationsSectionHtml = `
  <section class="section" aria-labelledby="mit-applied-h">
    <h2 id="mit-applied-h" class="section-head">Mitigations applied</h2>
    <p class="muted">No <span class="mono">--mitigations</span> file was provided. Add a JSON list of fixes to document what changed before this retest.</p>
  </section>`;
  } else {
    mitigationsSectionHtml = '';
  }

  let comparisonSectionHtml = '';
  if (isVerification && comparison) {
    const { counts } = comparison;
    const cmpRows = comparison.rows
      .map((line) => {
        const lb = line.baseline;
        const lp = line.post;
        const bLabel = !lb
          ? '—'
          : (lb.overall || '').toLowerCase() === 'pass' && !lb.blockingFailed
          ? 'Pass'
          : lb.blockingFailed
          ? 'Fail'
          : 'Review';
        const pLabel = !lp
          ? '—'
          : (lp.overall || '').toLowerCase() === 'pass' && !lp.blockingFailed
          ? 'Pass'
          : lp.blockingFailed
          ? 'Fail'
          : 'Review';
        let deltaClass = 'delta-neutral';
        if (String(line.delta).includes('Improved')) deltaClass = 'delta-up';
        else if (String(line.delta).includes('Regress') || String(line.delta).includes('Worsened')) deltaClass = 'delta-down';
        return `<tr>
          <td class="mono">${escapeHtml(line.testCaseId)}</td>
          <td>${escapeHtml(line.name)}</td>
          <td>${escapeHtml(bLabel)}</td>
          <td>${escapeHtml(pLabel)}</td>
          <td class="${deltaClass}">${escapeHtml(line.delta)}</td>
        </tr>`;
      })
      .join('');
    comparisonSectionHtml = `
  <section class="section" aria-labelledby="cmp-h">
    <h2 id="cmp-h" class="section-head">Before / after (baseline → retest)</h2>
    <p class="muted">Baseline: <span class="mono">${escapeHtml(baselinePath || '—')}</span><br/>
    Retest: <span class="mono">${escapeHtml(scorecardPath)}</span></p>
    <div class="delta-summary">
      <span class="delta-pill resolved"><strong>${escapeHtml(String(counts.resolved))}</strong> improved to pass</span>
      <span class="delta-pill still"><strong>${escapeHtml(String(counts.stillFailing))}</strong> still not pass</span>
      <span class="delta-pill regress"><strong>${escapeHtml(String(counts.regressed))}</strong> regressed</span>
      <span class="delta-pill neutral"><strong>${escapeHtml(String(counts.unchangedPass))}</strong> stayed pass</span>
    </div>
    <div class="table-wrap">
      <table class="compare-table">
        <thead><tr><th>Test ID</th><th>Name</th><th>Baseline</th><th>Retest</th><th>Δ</th></tr></thead>
        <tbody>${cmpRows}</tbody>
      </table>
    </div>
  </section>`;
  } else {
    comparisonSectionHtml = '';
  }

  const failedListHtml =
    exec.failedNames.length === 0
      ? '<li class="muted">None — all scenarios passed dimension checks.</li>'
      : exec.failedNames.map((n) => `<li>${escapeHtml(n)}</li>`).join('');

  const themesHtml =
    exec.topThemes.length === 0
      ? '<li class="muted">No themes matched (expand scenarios or update evidence-map.json keywords).</li>'
      : exec.topThemes
          .map((t) => {
            const title = (rows.find((rw) => (rw.matchedControls || []).some((c) => c.id === t.id)) || {})
              .matchedControls;
            const first = (title || []).find((c) => c.id === t.id);
            const label = first && first.title ? first.title : t.id;
            return `<li><strong>${escapeHtml(label)}</strong> — ${escapeHtml(String(t.count))} scenario(s)</li>`;
          })
          .join('');

  let scenarioDetails = '';
  for (const r of rows) {
    const resultLabel =
      r.overall === 'pass' && !r.blockingFailed ? 'Pass' : r.blockingFailed ? 'Fail (dimension)' : 'Review';
    let badgeClass = 'pass';
    if (r.blockingFailed) badgeClass = 'fail';
    else if ((r.overall || '').toLowerCase() !== 'pass') badgeClass = 'review';
    const scoreStr = r.successRate != null ? String(r.successRate) : '—';

    const failedList =
      r.failedChecks.length === 0
        ? '<p class="muted">No failing dimension checks in scorecard layer2.</p>'
        : `<ul class="fail-list">${r.failedChecks
            .map(
              (f) =>
                `<li><span class="dim">${escapeHtml(f.dimension)}</span> (${escapeHtml(f.id)}): ${escapeHtml(f.reason)}</li>`
            )
            .join('')}</ul>`;

    const lawHtml = renderLawThemeCards(r.matchedControls, evidenceMap);
    const openAttr = r.blockingFailed ? ' open' : '';

    scenarioDetails += `
    <details class="scenario-block"${openAttr}>
      <summary class="scenario-sum">
        <span class="sum-badge ${badgeClass}">${escapeHtml(resultLabel)}</span>
        <span class="sum-title">${escapeHtml(r.name || r.testCaseId)}</span>
        <span class="sum-meta mono">${escapeHtml(r.testCaseId || '')}</span>
        <span class="sum-score">Score: ${escapeHtml(scoreStr)}</span>
      </summary>
      <div class="scenario-body">
        <h4 class="info-h">Failing checks (from evaluation harness)</h4>
        ${failedList}
        <h4 class="info-h">Law, regulation &amp; case themes</h4>
        ${lawHtml}
      </div>
    </details>`;
  }

  let mitigationHtml = '';
  if (mitCatalog.length === 0) {
    mitigationHtml =
      '<p class="muted">No compliance themes were matched across scenarios, so no consolidated mitigation list was generated. Review scenarios manually against the reference document, or broaden <span class="mono">evidence-map.json</span> keywords.</p>';
  } else {
    for (const block of mitCatalog) {
      mitigationHtml += `<div class="mitigation-block"><h3 class="mitigation-h">${escapeHtml(block.title)}</h3><ol class="mitigation-steps">${(
        block.steps || []
      )
        .map((s) => `<li>${escapeHtml(s)}</li>`)
        .join('')}</ol></div>`;
    }
  }

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1"/>
  <title>${escapeHtml(docTitle)} — ${escapeHtml(scData.run_id || 'run')}</title>
  <style>
    :root {
      --border: #c8d0d8;
      --bg-page: #f6f8fa;
      --bg-card: #fff;
      --accent: #1565c0;
      --fail: #b71c1c;
      --pass: #1b5e20;
      --review: #6d4c41;
    }
    * { box-sizing: border-box; }
    body {
      font-family: "Segoe UI", system-ui, -apple-system, sans-serif;
      margin: 0;
      padding: 1.5rem 1.75rem 2.5rem;
      line-height: 1.5;
      color: #1a1a1a;
      background: var(--bg-page);
      max-width: 58rem;
      margin-left: auto;
      margin-right: auto;
    }
    .doc-title {
      font-size: 1.5rem;
      font-weight: 650;
      margin: 0 0 0.25rem;
      letter-spacing: -0.02em;
    }
    .doc-sub { color: #555; font-size: 0.95rem; margin: 0 0 1.25rem; }

    .section {
      background: var(--bg-card);
      border: 1px solid var(--border);
      border-radius: 8px;
      padding: 1rem 1.15rem 1.15rem;
      margin-bottom: 1rem;
      box-shadow: 0 1px 2px rgba(0,0,0,.04);
    }
    .section > h2, .section-head {
      font-size: 1.05rem;
      margin: 0 0 0.65rem;
      padding-bottom: 0.4rem;
      border-bottom: 2px solid var(--accent);
      color: #0d2c54;
    }

    .banner { background: #e8eef4; border: 1px solid var(--border); padding: 0.85rem 1rem; border-radius: 6px; }
    .banner strong { display: block; margin-bottom: 0.35rem; color: #0d2c54; }

    .exec-summary {
      background: linear-gradient(180deg, #fff 0%, #f8fafc 100%);
      border-left: 4px solid var(--accent);
    }
    .exec-grid {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(9.5rem, 1fr));
      gap: 0.65rem;
      margin: 0.75rem 0 1rem;
    }
    .stat {
      background: #fff;
      border: 1px solid var(--border);
      border-radius: 6px;
      padding: 0.5rem 0.65rem;
      text-align: center;
    }
    .stat-val { font-size: 1.35rem; font-weight: 700; line-height: 1.2; }
    .stat-val.pass { color: var(--pass); }
    .stat-val.fail { color: var(--fail); }
    .stat-val.mutedN { color: #546e7a; }
    .stat-lbl { font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.04em; color: #607d8b; margin-top: 0.2rem; }

    .exec-lists { display: grid; grid-template-columns: 1fr 1fr; gap: 1rem; }
    @media (max-width: 720px) { .exec-lists { grid-template-columns: 1fr; } }

    .mono { font-family: ui-monospace, Consolas, "Courier New", monospace; font-size: 0.82rem; word-break: break-all; }
    .muted { color: #555; font-size: 0.9rem; }
    .pass { color: var(--pass); font-weight: 700; }
    .fail { color: var(--fail); font-weight: 700; }

    details.meta-details { margin-top: 0.35rem; }
    details.meta-details summary {
      cursor: pointer;
      font-weight: 600;
      color: var(--accent);
      padding: 0.25rem 0;
    }
    .meta-grid {
      display: grid;
      gap: 0.35rem;
      font-size: 0.88rem;
      margin-top: 0.5rem;
      padding: 0.5rem;
      background: #f8fafc;
      border-radius: 6px;
    }
    .meta-grid dt { font-weight: 600; color: #455a64; }
    .meta-grid dd { margin: 0 0 0.4rem 0; }

    .scenario-block {
      border: 1px solid var(--border);
      border-radius: 6px;
      margin-bottom: 0.5rem;
      background: #fff;
      overflow: hidden;
    }
    .scenario-block summary { list-style: none; }
    .scenario-block summary::-webkit-details-marker { display: none; }
    .scenario-sum {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 0.5rem 0.75rem;
      padding: 0.55rem 0.75rem;
      cursor: pointer;
      background: #f1f4f7;
      font-weight: 500;
    }
    .scenario-block[open] .scenario-sum { border-bottom: 1px solid var(--border); background: #e8edf2; }
    .sum-badge {
      font-size: 0.72rem;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      padding: 0.2rem 0.45rem;
      border-radius: 4px;
      min-width: 4.5rem;
      text-align: center;
    }
    .sum-badge.pass { background: #e8f5e9; color: var(--pass); }
    .sum-badge.fail { background: #ffebee; color: var(--fail); }
    .sum-badge.review { background: #efebe9; color: var(--review); }
    .sum-title { flex: 1 1 12rem; }
    .sum-meta { font-size: 0.8rem; color: #546e7a; }
    .sum-score { font-size: 0.85rem; color: #455a64; }

    .scenario-body { padding: 0.75rem 1rem 1rem; }
    .info-h {
      font-size: 0.8rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
      color: #455a64;
      margin: 0.75rem 0 0.35rem;
      border-left: 3px solid var(--accent);
      padding-left: 0.4rem;
    }
    .scenario-body .info-h:first-child { margin-top: 0; }

    .card {
      border: 1px solid #dde3e9;
      border-radius: 6px;
      padding: 0.55rem 0.7rem;
      margin: 0.45rem 0;
      background: #fafbfd;
    }
    .card-h { font-size: 0.95rem; margin: 0 0 0.35rem; color: #102a43; }
    .small-heading { font-size: 0.72rem; text-transform: uppercase; letter-spacing: 0.04em; color: #546e7a; margin: 0.4rem 0 0.2rem; }
    .small-note { font-size: 0.82rem; margin: 0.5rem 0 0; }
    .fail-list { margin: 0.25rem 0; padding-left: 1.2rem; }
    .dim { font-weight: 600; }

    #mitigation-catalog { scroll-margin-top: 1rem; }
    .mitigation-block {
      border: 1px solid var(--border);
      border-radius: 6px;
      padding: 0.65rem 0.85rem;
      margin: 0.65rem 0;
      background: #fafbfd;
    }
    .mitigation-h { font-size: 0.95rem; margin: 0 0 0.35rem; color: #102a43; }
    .mitigation-steps { margin: 0.25rem 0 0; padding-left: 1.25rem; }
    .mitigation-steps li { margin: 0.25rem 0; }

    .mitigations-applied-list { margin: 0.5rem 0 0; padding-left: 1.2rem; }
    .mit-applied-li { margin: 0.65rem 0; }
    .mit-applied-h { font-weight: 600; color: #102a43; }
    .mit-applied-d { margin: 0.25rem 0 0; }

    .delta-summary { display: flex; flex-wrap: wrap; gap: 0.45rem; margin: 0.75rem 0 1rem; }
    .delta-pill {
      font-size: 0.82rem;
      padding: 0.35rem 0.55rem;
      border-radius: 6px;
      border: 1px solid var(--border);
      background: #fff;
    }
    .delta-pill.resolved { border-color: #a5d6a7; background: #e8f5e9; }
    .delta-pill.still { border-color: #ffccbc; background: #fff3e0; }
    .delta-pill.regress { border-color: #ef9a9a; background: #ffebee; }
    .delta-pill.neutral { background: #eceff1; }

    .table-wrap { overflow-x: auto; margin-top: 0.5rem; }
    .compare-table { width: 100%; border-collapse: collapse; font-size: 0.84rem; }
    .compare-table th, .compare-table td { border: 1px solid var(--border); padding: 0.45rem 0.5rem; text-align: left; }
    .compare-table th { background: #e8eef4; }
    .delta-up { color: var(--pass); font-weight: 600; }
    .delta-down { color: var(--fail); font-weight: 600; }
    .delta-neutral { color: #546e7a; }

    @media print {
      body { background: #fff; max-width: none; padding: 0.4cm; }
      .section { box-shadow: none; break-inside: avoid; }
      .scenario-block { break-inside: avoid; }
      details.meta-details { display: block; }
      details.meta-details summary { list-style: none; }
    }
  </style>
</head>
<body>

  <header class="doc-header">
    <h1 class="doc-title">${escapeHtml(docTitle)}</h1>
    <p class="doc-sub">${escapeHtml(docSub)}</p>
  </header>

  <section class="section banner" aria-label="Disclaimer">
    <strong>Disclaimer — not legal advice</strong>
    This report maps evaluation results to topics described in the bundled research compendium
    (<cite>AI and Virtual Agent Laws, Court Cases and Compliance Standards</cite>, v.${escapeHtml(docVersion)} in source).
    It does not analyze your specific jurisdictional footprint. Have qualified counsel confirm applicability before relying on any entry.
  </section>

  <section class="section exec-summary" aria-labelledby="exec-h">
    <h2 id="exec-h" class="section-head">Executive summary</h2>
    <p class="muted" style="margin-top:0">${
      isVerification
        ? 'Retest snapshot after mitigations: scenario outcomes in the new run, plus (below) recorded fixes and a baseline → retest comparison when a baseline scorecard was supplied.'
        : 'Snapshot of this run: scenario outcomes, where dimension checks failed, and which compliance themes matched most often.'
    }</p>

    <div class="exec-grid" role="group" aria-label="Outcome counts">
      <div class="stat"><div class="stat-val mutedN">${escapeHtml(String(exec.total))}</div><div class="stat-lbl">Scenarios</div></div>
      <div class="stat"><div class="stat-val pass">${escapeHtml(String(exec.pass))}</div><div class="stat-lbl">Pass</div></div>
      <div class="stat"><div class="stat-val fail">${escapeHtml(String(exec.failDim))}</div><div class="stat-lbl">Fail (dimension)</div></div>
      <div class="stat"><div class="stat-val mutedN">${escapeHtml(String(exec.review))}</div><div class="stat-lbl">Review</div></div>
      <div class="stat"><div class="stat-val mutedN">${escapeHtml(String(exec.pct))}%</div><div class="stat-lbl">Pass rate</div></div>
    </div>

    <p><strong>Harness summary (scorecard file):</strong> passed ${escapeHtml(String(exec.summaryPassed ?? '—'))} / ${escapeHtml(
    String(exec.summaryTotal ?? '—')
  )} — failed ${escapeHtml(String(exec.summaryFailed ?? '—'))}, infrastructure errors ${escapeHtml(
    String(exec.summaryInfra ?? '—')
  )}.</p>

    <div class="exec-lists">
      <div>
        <h3 class="info-h" style="margin-top:0">Scenarios with failing dimension checks</h3>
        <ul>${failedListHtml}</ul>
      </div>
      <div>
        <h3 class="info-h" style="margin-top:0">Most common matched compliance themes</h3>
        <ul>${themesHtml}</ul>
      </div>
    </div>

    <p class="muted"><strong>Deployment profile:</strong> ${escapeHtml(depProfile.label || depKey)} — ${escapeHtml(
    depProfile.description || ''
  )}</p>
    <p class="muted">${fedrampNote}</p>
    <p class="muted"><strong>Mapping note:</strong> Themes come from keyword matches in scenario text and failures against <span class="mono">evidence-map.json</span> only. ${escapeHtml(
      String(exec.unmapped)
    )} scenario(s) had no automated theme match — review those against <cite>${escapeHtml(
    path.basename(sourcePath)
  )}</cite> manually.</p>

    <p class="muted"><strong>Suggested next step:</strong> ${
      isVerification && comparison
        ? comparison.counts.stillFailing > 0 || comparison.counts.regressed > 0
          ? `Revisit scenarios that are still failing or regressed (see <a href="#cmp-h">§ Before / after</a>), then confirm with counsel. The <a href="#mitigation-catalog">§ Mitigation catalog</a> lists generic theme-based actions from the reference compendium.`
          : `All compared scenarios passed or stayed pass. Archive this report with <a href="#mit-applied-h">§ Mitigations applied</a> and keep counsel in the loop for jurisdictional fit.`
        : isVerification && !comparison
        ? `For a full before/after table, re-run with <span class="mono">--baseline-scorecard</span> pointing to the pre-fix eval. Until then, use <a href="#mitigation-catalog">§ Mitigation catalog</a> and the retest details above.`
        : `address items in <a href="#mitigation-catalog">§ Mitigation catalog</a> below, then re-run evaluation.`
    }</p>
  </section>

  ${mitigationsSectionHtml}

  ${comparisonSectionHtml}

  <section class="section" aria-labelledby="meta-h">
    <details class="meta-details">
      <summary id="meta-h">Report metadata &amp; inputs (click to expand)</summary>
      <dl class="meta-grid">
        <dt>Generated (UTC)</dt><dd>${escapeHtml(generated)}</dd>
        <dt>Report type</dt><dd>${escapeHtml(isVerification ? 'Verification (retest after mitigations)' : 'Assessment (single run)')}</dd>
        <dt>Deployment profile</dt><dd>${escapeHtml(depProfile.label || depKey)} (<span class="mono">${escapeHtml(depKey)}</span>)</dd>
        <dt>Run ID (retest)</dt><dd class="mono">${escapeHtml(scData.run_id || '—')}</dd>
        <dt>Agent / version</dt><dd class="mono">${escapeHtml(String(scData.agentId || '—'))} / ${escapeHtml(String(scData.version || '—'))}</dd>
        <dt>Retest scorecard</dt><dd class="mono">${escapeHtml(scorecardPath)}</dd>
        ${isVerification && baselinePath ? `<dt>Baseline scorecard</dt><dd class="mono">${escapeHtml(baselinePath)}</dd>` : ''}
        <dt>Reference document</dt><dd class="mono">${escapeHtml(sourcePath)}</dd>
        <dt>Rubric</dt><dd>${escapeHtml(meta.rubricVersion != null ? String(meta.rubricVersion) : '—')} <span class="muted">(from scorecard metadata)</span></dd>
      </dl>
    </details>
  </section>

  <section class="section" aria-labelledby="tests-h">
    <h2 id="tests-h" class="section-head">${isVerification ? 'Retest — test-by-test results' : 'Test-by-test results'}</h2>
    <p class="muted">Each block is one scenario from the ${isVerification ? '<strong>retest</strong> ' : ''}scorecard. Click a row to expand failing checks and law/case themes. Theme-based remediation remains in the mitigation catalog at the end.</p>
    ${scenarioDetails}
  </section>

  <section class="section" id="mitigation-catalog" aria-labelledby="mit-h">
    <h2 id="mit-h" class="section-head">Mitigation catalog</h2>
    <p class="muted">Consolidated steps from all matched compliance themes (deduplicated). Use this as a checklist for AVA instructions, guardrails, tooling, and process — then confirm with counsel for your jurisdictions.</p>
    ${mitigationHtml}
  </section>

</body>
</html>`;
}

async function tryPrintPdf(htmlPath, pdfPath) {
  try {
    const puppeteer = require('puppeteer');
    const browser = await puppeteer.launch({ headless: true });
    const page = await browser.newPage();
    await page.goto('file://' + htmlPath.replace(/\\/g, '/'), { waitUntil: 'networkidle0' });
    await page.evaluate(() => {
      document.querySelectorAll('details').forEach((d) => {
        d.open = true;
      });
    });
    await page.pdf({
      path: pdfPath,
      format: 'A4',
      printBackground: true,
      margin: { top: '12mm', bottom: '14mm', left: '12mm', right: '12mm' },
    });
    await browser.close();
    return true;
  } catch (_e) {
    return false;
  }
}

async function main() {
  const args = parseArgs();
  if (!args.scorecard || !fs.existsSync(args.scorecard)) {
    console.error(
      'Usage: node generate-compliance-report.js --scorecard <post-mitigation scorecard.json> [options]\n' +
        '  [--baseline-scorecard <prior scorecard.json>] [--mitigations <mitigations.json>]\n' +
        '  [--deployment commercial|us-government]  FedRAMP/§3.10 only for us-government\n' +
        '  [--out-dir <dir>] [--output-html <filename>] [--evidence-map <path>] [--themes-from all|failures] [--no-pdf]'
    );
    process.exit(1);
  }
  if (args.baselineScorecard && !fs.existsSync(args.baselineScorecard)) {
    console.error('Baseline scorecard not found:', args.baselineScorecard);
    process.exit(1);
  }
  if (args.mitigations && !fs.existsSync(args.mitigations)) {
    console.error('Mitigations file not found:', args.mitigations);
    process.exit(1);
  }
  if (!fs.existsSync(args.outDir)) fs.mkdirSync(args.outDir, { recursive: true });

  const evidenceMapPath = args.evidenceMap || defaultEvidenceMap;
  if (!fs.existsSync(evidenceMapPath)) {
    console.error('Missing evidence map:', evidenceMapPath);
    process.exit(1);
  }
  const evidenceMapRaw = loadJson(evidenceMapPath);
  const evidenceMap = filterEvidenceMapForDeployment(
    evidenceMapRaw,
    args.deployment || evidenceMapRaw.default_deployment_profile || 'commercial'
  );
  const scData = loadJson(args.scorecard);
  let baselineScData = null;
  if (args.baselineScorecard) baselineScData = loadJson(args.baselineScorecard);

  const sourceMd = path.join(skillDir, 'assets', 'AI_and_Virtual_Agent_Laws_Cases_and_Compliance_Standards.md');
  if (!fs.existsSync(sourceMd)) {
    console.error('Missing bundled source:', sourceMd);
    process.exit(1);
  }

  if (!['all', 'failures'].includes(args.themesFrom)) {
    console.error("--themes-from must be 'all' or 'failures'");
    process.exit(1);
  }
  const rows = buildRows(scData, evidenceMap, args.themesFrom);

  let comparison = null;
  if (baselineScData) {
    const baselineRows = buildRows(baselineScData, evidenceMap, args.themesFrom);
    comparison = compareRuns(baselineRows, rows);
  }

  let mitigationsDoc = null;
  if (args.mitigations) {
    try {
      mitigationsDoc = loadMitigationsFile(args.mitigations);
    } catch (e) {
      console.error(e.message || String(e));
      process.exit(1);
    }
  }

  const verificationMode = !!(baselineScData || (mitigationsDoc && (mitigationsDoc.items || []).length > 0));

  const html = renderHtml({
    scData,
    evidenceMap,
    rows,
    sourcePath: sourceMd,
    scorecardPath: args.scorecard,
    baselineScData: baselineScData || null,
    baselinePath: args.baselineScorecard || null,
    comparison: comparison || null,
    mitigationsDoc: mitigationsDoc || null,
    verificationMode: verificationMode,
    activeDeployment: evidenceMap._activeDeployment,
    deploymentProfiles: evidenceMapRaw.deployment_profiles,
  });

  let outHtmlName = args.outputHtml;
  if (!outHtmlName) {
    if (args.baselineScorecard || args.mitigations) outHtmlName = 'compliance-verification-report.html';
    else outHtmlName = 'compliance-report.html';
  }
  const htmlPath = path.join(args.outDir, outHtmlName);
  const pdfBase = path.basename(outHtmlName, path.extname(outHtmlName));
  const pdfPath = path.join(args.outDir, `${pdfBase}.pdf`);
  fs.writeFileSync(htmlPath, html, 'utf8');
  console.log('Wrote', htmlPath);

  if (args.pdf) {
    const ok = await tryPrintPdf(htmlPath, pdfPath);
    if (ok) console.log('Wrote', pdfPath);
    else {
      console.log(
        'PDF skipped: install Puppeteer in this environment (`npm install puppeteer`) or print the HTML to PDF from a browser.'
      );
    }
  }
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
