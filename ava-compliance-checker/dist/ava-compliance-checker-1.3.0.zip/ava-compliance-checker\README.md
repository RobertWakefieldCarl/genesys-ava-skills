# ava-compliance-checker

Maps **AVA `scorecard.json`** results to themes from **one** bundled document — *AI and Virtual Agent Laws, Court Cases and Compliance Standards* — and writes **compliance-report.html** (+ **.pdf** with Puppeteer).

**Install:** extract the release zip and run `install.ps1` (Windows) or `install.sh` (macOS/Linux) from the extracted `ava-compliance-checker` folder — default target `~/.cursor/skills/ava-compliance-checker/`. Use `-All` / `--all` to copy into every detected IDE base under your profile.

**Package (maintainers):** from the skill folder run `pwsh ./scripts/package.ps1` — produces **`dist/ava-compliance-checker-<version>.zip`** with a printed SHA256 (see `MANIFEST.json` for file list).

## Quick command

```bash
node scripts/generate-compliance-report.js --scorecard "path/to/scorecard.json" --deployment commercial --customer AXL-pitstop5

When `--customer` or a scorecard path under `axl-sessions` is set, output goes to that customer's `compliance/<run-id>/` folder automatically. Reports include a colorful **What was tested and why** overview (use `--spec` and `--test-cases-dir` when available).

FedRAMP and §3.10 government checks apply only with `--deployment us-government` (US state & federal government).
```

The HTML report includes an **executive summary**, **collapsible** scenario sections, and a **mitigation catalog** at the end. Puppeteer PDF export opens every section so the PDF is fully readable.

**Verification (after fixes + retest):** pass **`--baseline-scorecard`** (pre-fix) and optionally **`--mitigations`** (JSON describing what changed). Default output: **`compliance-verification-report.html`**. See **`examples/mitigations.example.json`**.

See **SKILL.md** for the full agent workflow and disclaimer.
